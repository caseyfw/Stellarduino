#include "StdAfx.h"
#include ".\serialinterface.h"
#include "EQ6ControlPanelDoc.h"


SerialInterface::SerialInterface(void)
{
	m_hCom = INVALID_HANDLE_VALUE;
}

SerialInterface::~SerialInterface(void)
{
	if (isOpen())
		closePort();
}

BOOL SerialInterface::openPort(CString portName)
{
	// variables used with the com port
	BOOL     m_bPortReady;
	DCB      m_dcb;
	COMMTIMEOUTS m_CommTimeouts;

	// Note: Code in this function is adapted from http://www.ontrak.net/mfc.htm

	// Close port if there is one already open
	if (m_hCom != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_hCom);
		m_hCom = INVALID_HANDLE_VALUE;
	}
	
	// Open the port
	m_hCom = CreateFile(portName, 
			GENERIC_READ | GENERIC_WRITE,
			0, // exclusive access
			NULL, // no security
			OPEN_EXISTING,
			0, // no overlapped I/O
			NULL); // null template

	// Check to see if the open was successful
	if (m_hCom == INVALID_HANDLE_VALUE)
		return FALSE;

	// Set the buffer sizes
	m_bPortReady = SetupComm(m_hCom, 128, 128);

	// Setup the serial port parameters - 8n1
	m_bPortReady = GetCommState(m_hCom, &m_dcb);
	m_dcb.BaudRate = 9600;
	m_dcb.ByteSize = 8;
	m_dcb.Parity = NOPARITY;
	m_dcb.StopBits = ONESTOPBIT;
	m_dcb.fAbortOnError = TRUE;

	m_bPortReady = SetCommState(m_hCom, &m_dcb);

	m_bPortReady = GetCommTimeouts (m_hCom, &m_CommTimeouts);

	// Setup communication timeouts
	m_CommTimeouts.ReadIntervalTimeout = 50;
	m_CommTimeouts.ReadTotalTimeoutConstant = 50;
	m_CommTimeouts.ReadTotalTimeoutMultiplier = 10;
	m_CommTimeouts.WriteTotalTimeoutConstant = 50;
	m_CommTimeouts.WriteTotalTimeoutMultiplier = 10;

	m_bPortReady = SetCommTimeouts (m_hCom, &m_CommTimeouts);

	return TRUE;
}

BOOL SerialInterface::isOpen(void)
{
	return m_hCom != INVALID_HANDLE_VALUE;
}

void SerialInterface::closePort(void)
{
	if (m_hCom != INVALID_HANDLE_VALUE)
	{
		CloseHandle(m_hCom);
		m_hCom = INVALID_HANDLE_VALUE;
	}
}

BOOL SerialInterface::updateFromDoc(void* pVDoc)
{
	CEQ6ControlPanelDoc* pDoc = (CEQ6ControlPanelDoc *)pVDoc;
	
	if (m_hCom == INVALID_HANDLE_VALUE)
	{
		AfxMessageBox("Open a communication port first");
		return FALSE;
	}

	// Communications port is open - output the information
	BOOL	bWriteRC;
	DWORD	iBytesWritten;

	CString	outStr;

	// Write out the tracking rate information (if changed)
	if (pDoc->rateChanged)
	{

		// Update the tracking rate table
		for (unsigned short cursor = 0 ; cursor < 3 ; ++cursor)
		{

/* Note: The track rate table contains the amount that the
 * XTAL frequency needs to be divided by to generate step interrupts.
 *
 * The divisor is:
 *
 * (secs_per_360 * clk_freq) / (lcm * mech_div * steps_per_step_rotn)
 *
 * This will not necessarily be an integer. If rounded we may get errors up
 * to 1 in 10^3. The fractional part can be realized by dropping one
 * interrupt every rnd(divisor) / (divisor - rnd(divisor).
 *
 * Negative numbers represent cases where interrupts should be added (ie the
 * ISR executed again)
 */
#define STEPS_PER_CYCLE     32.0	/* Steps per cycle (complete set of phases) */
#define SIDERIAL_LCM        (3.0 * 16.0)    /* Divides to give all speeds */
#define EQ6_WORM_RATIO      180.0	/* Tooth on EQ6 worm gear */

			LONG	divisor;
			LONG	remainder;

			double	calc_val;

			// Calculate the correct divisor
			calc_val =		(double)pDoc->secsPerRotation[cursor]
							* (double)pDoc->clockFreq;
			calc_val /=		48.0		// Rate LCM - see mount source
							* EQ6_WORM_RATIO
							* STEPS_PER_CYCLE
							* (double)pDoc->stepsPerRotation / 4
							* pDoc->gearboxRatio;

			// Convert to integers
			divisor = (int)(calc_val + 0.5);
			remainder = (double)divisor / (calc_val - (double)divisor);

			if (		(remainder <= -((1 << 16) - 2)) 
						|| (remainder >= ((1 << 16) - 2)))
					remainder = 0;

			// Send it to the mount
			outStr.Format(		"#%dc#%ds#%da#%dp", 
								cursor,
								divisor,
								remainder,
								pDoc->secsPerRotation[cursor]);

			bWriteRC = WriteFile(	m_hCom, 
									outStr, 
									outStr.GetLength(),
									&iBytesWritten,
									NULL);
			if ( ! bWriteRC)
				goto err_exit;
		}

		pDoc->rateChanged = FALSE;
		pDoc->trackingChanged = TRUE;	// Force tracking rate update

	}

	if (pDoc->trackingChanged)
	{
		// Set the tracking rate. This will cause the current rate
		// divisors to be updated
		outStr.Format("#%dT", pDoc->trackingRate);
		bWriteRC = WriteFile(	m_hCom, 
								outStr, 
								outStr.GetLength(),
								&iBytesWritten,
								NULL);
		if ( ! bWriteRC)
		{
err_exit:
			AfxMessageBox("Error writing data");
			return FALSE;
		}

		pDoc->trackingChanged = FALSE;
	}
	
	// Write out the misc information (if changed)
	if (pDoc->miscChanged)
	{
		outStr.Format(		"%cG%cS%cd",
							pDoc->paddle_0_3_x ? '>' : '<',
							pDoc->slew_24_x ? '>' : '<',
							pDoc->deltaSync ? '>' : '<');
							
		bWriteRC = WriteFile(	m_hCom, 
								outStr, 
								outStr.GetLength(),
								&iBytesWritten,
								NULL);
		if ( ! bWriteRC)
			goto err_exit;

		pDoc->miscChanged = FALSE;
	}

	// Write the RA backlash information if changed
	if (pDoc->raBacklashChanged)
	{
		int		mode;

		switch (pDoc->ra.mode)
		{
		case pDoc->ra.E_BL_NEG:		mode = -1; break;
		case pDoc->ra.E_BL_NORM:	mode = 0; break;
		case pDoc->ra.E_BL_POS:		mode = 1; break;
		}

		outStr.Format(		"#%dm#%db",
							mode,
							pDoc->ra.steps);
							
		bWriteRC = WriteFile(	m_hCom, 
								outStr, 
								outStr.GetLength(),
								&iBytesWritten,
								NULL);
		if ( ! bWriteRC)
			goto err_exit;

		pDoc->raBacklashChanged = FALSE;
	}

	// Write the DEC backlash information if changed
	if (pDoc->decBacklashChanged)
	{
		int		mode;

		switch (pDoc->dec.mode)
		{
		case pDoc->dec.E_BL_NEG:		mode = -1; break;
		case pDoc->dec.E_BL_NORM:		mode = 0; break;
		case pDoc->dec.E_BL_POS:		mode = 1; break;
		}

		outStr.Format(		"#%dM#%dB",
							mode,
							pDoc->dec.steps);
							
		bWriteRC = WriteFile(	m_hCom, 
								outStr, 
								outStr.GetLength(),
								&iBytesWritten,
								NULL);

		if ( ! bWriteRC)
			goto err_exit;

		pDoc->decBacklashChanged = FALSE;
	}
	
	// Update the polar scope illumination value
	if (pDoc->ledChanged)
	{
		updatePolar(pDoc->polarLevel);

		pDoc->ledChanged = FALSE;
	}

	return TRUE;
}

// Send the specified string and get the response
CString * SerialInterface::sendCmdGetResponse(CString &cmdStr, int maxLength)
{
	BOOL	bWriteRC;
	DWORD	iBytesWritten;

	// Write out the prompt
	bWriteRC = WriteFile(	m_hCom, 
							cmdStr, 
							cmdStr.GetLength(),
							&iBytesWritten,
							NULL);

	if ( ! bWriteRC)
		return 0;

	// Wait for some response
	char*	pInpBuffer = new char[maxLength];
	BOOL	bReadRC;
	DWORD	iBytesRead;

	bReadRC = ReadFile(m_hCom, pInpBuffer, maxLength, &iBytesRead, NULL);
	if ( ! bReadRC)
	{
		delete(pInpBuffer);
		return 0;
	}

	// Return the result
	if (iBytesRead > 0)
	{
		CString* pRetStr = new CString;

		pInpBuffer[iBytesRead] = '\0';
		pRetStr->Format("%s", pInpBuffer);

		delete pInpBuffer;
		return pRetStr;
	}
	else
	{
		delete pInpBuffer;
		return 0;
	}
}
void SerialInterface::updatePolar(unsigned char polarLevel)
{
	BOOL	bWriteRC;
	DWORD	iBytesWritten;

	CString	outStr;
	
	if (m_hCom == INVALID_HANDLE_VALUE)
		return;		// No valid port yet
	
	outStr.Format(		"#%dP", polarLevel);
							
	bWriteRC = WriteFile(	m_hCom, 
							outStr, 
							outStr.GetLength(),
							&iBytesWritten,
							NULL);
}
