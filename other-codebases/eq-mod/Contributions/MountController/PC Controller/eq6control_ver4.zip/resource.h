//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by EQ6ControlPanel.rc
//
#define IDD_ABOUTBOX                    100
#define IDP_OLE_INIT_FAILED             100
#define IDD_EQ6CONTROLPANEL_FORM        101
#define IDR_MAINFRAME                   128
#define IDR_EQ6ControlPanelTYPE         129
#define IDD_MOUNT_VERSION               131
#define IDC_TRK_SIDEREAL                1001
#define IDC_TRK_SOLAR                   1002
#define IDC_TRK_LUNAR                   1003
#define IDC_M_DELTA                     1004
#define IDC_RA_FIN_POS                  1006
#define IDC_RA_NORMAL                   1007
#define IDC_RA_FIN_NEG                  1008
#define IDC_RA_STEPS                    1009
#define IDC_DEC_FIN_POS                 1010
#define IDC_DEC_NORMAL                  1011
#define IDC_DEC_FIN_NEG                 1012
#define IDC_DEC_STEPS                   1013
#define IDC_UPDATE_MOUNT                1014
#define IDC_TRK_NONE                    1016
#define IDC_M_GOTO                      1018
#define IDC_M_PADDLE                    1019
#define IDC_NAME                        1021
#define IDC_VERSION                     1022
#define IDC_DATE                        1023
#define IDC_HW_16MHZ                    1027
#define IDC_HW_8MHZ                     1028
#define IDC_HW_STEPS                    1029
#define ID_M_SOLAR                      1031
#define ID_M_LUNAR                      1032
#define ID_M_SIDEREAL                   1034
#define IDC_POLAR_LEVEL                 1038
#define IDC_GB_COMBO                    1043
#define IDC_GB_COMBO2                   1044
#define IDC_COMBO3                      1045
#define ID_COM_COM1                     32771
#define ID_COM_COM2                     32772
#define ID_COM_COM3                     32773
#define ID_COM_COM4                     32774
#define ID_COM_COM5                     32775
#define ID_COM_COM6                     32776
#define ID_MOUNTINFORMATION             32777
#define ID_COMM_COM7                    32778
#define ID_COMM_COM8                    32779
#define ID_SETTODEFAULT                 32780

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32781
#define _APS_NEXT_CONTROL_VALUE         1046
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
