// EQ6ControlPanelView.h : interface of the CEQ6ControlPanelView class
//


#pragma once
#include "afxwin.h"

#include "EQ6ControlPanelDoc.h"
#include "afxcmn.h"


class CEQ6ControlPanelView : public CFormView
{
protected: // create from serialization only
	CEQ6ControlPanelView();
	DECLARE_DYNCREATE(CEQ6ControlPanelView)

public:
	enum{ IDD = IDD_EQ6CONTROLPANEL_FORM };

// Attributes
public:
	CEQ6ControlPanelDoc* GetDocument() const;

// Operations
public:

// Overrides
	public:
virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void OnInitialUpdate(); // called first time after construct

// Implementation
public:
	virtual ~CEQ6ControlPanelView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:
	CEdit m_raSteps;
	CEdit m_decSteps;
	CButton m_delta;
	CButton m_goto;
	CButton m_paddle;

	int	m_raButton;
	int	m_decButton;
	int	m_trkButton;

protected:
	virtual void OnDraw(CDC* /*pDC*/);
public:
	afx_msg void OnBnClickedTrk();
	afx_msg void OnBnClickedRa();
	afx_msg void OnBnClickedDec();
	VOID UpdateBacklashButton(int& button, backlash_t & backlash);
	afx_msg void OnBnClickedMDelta();
	afx_msg void OnBnClickedMGoto();
	afx_msg void OnBnClickedMPaddle();
	afx_msg void OnEnChangeRaSteps();
	afx_msg void OnEnKillfocusRaSteps();
	afx_msg void OnEnKillfocusDecSteps();
	BOOL UpdateBacklashValue(CEdit & editCtrl, backlash_t & backlash);
	afx_msg void OnBnClickedUpdateMount();
	CButton m_update;
	void updateGlobal(BOOL bModified = 1);
	CEdit m_stepsRotn;
	
	BOOL UpdatePeriodValue(CEdit & editCtrl, unsigned long & secsPerRotation);
	afx_msg void OnEnKillfocusHwSteps();
	afx_msg void OnBnClickedHw16mhz();
	int m_clockFreqButton;
	CEdit m_solarPeriod;
	CEdit m_lunarPeriod;
	CEdit m_siderealPeriod;
	afx_msg void OnEnKillfocusMSidereal();
	afx_msg void OnEnKillfocusMSolar();
	afx_msg void OnEnKillfocusMLunar();
private:
	BOOL bRedrawing;
public:
	afx_msg void OnSettodefault();
	afx_msg void OnBnClickedHwEq6();
	CSliderCtrl m_polarLevel;
	afx_msg void OnNMCustomdrawPolarLevel(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMReleasedcapturePolarLevel(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnBnClickedRadio1();
	afx_msg void OnBnClickedRadio2();
	CComboBox m_gearbox;
	afx_msg void OnCbnKillfocusGbCombo();
};

#ifndef _DEBUG  // debug version in EQ6ControlPanelView.cpp
inline CEQ6ControlPanelDoc* CEQ6ControlPanelView::GetDocument() const
   { return reinterpret_cast<CEQ6ControlPanelDoc*>(m_pDocument); }
#endif

