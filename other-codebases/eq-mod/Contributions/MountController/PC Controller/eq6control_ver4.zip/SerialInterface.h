#pragma once

class SerialInterface
{
public:
	SerialInterface(void);
	~SerialInterface(void);
	BOOL openPort(CString portName);
	BOOL isOpen(void);
	void closePort(void);
    BOOL updateFromDoc(void* pVDoc);
	void updatePolar(unsigned char polarLevel);
	CString * sendCmdGetResponse(CString &cmdStr, int maxLength = 128);
private:
	HANDLE m_hCom;
};
