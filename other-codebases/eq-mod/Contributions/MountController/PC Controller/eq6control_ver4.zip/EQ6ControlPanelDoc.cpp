// EQ6ControlPanelDoc.cpp : implementation of the CEQ6ControlPanelDoc class
//

#include "stdafx.h"
#include "EQ6ControlPanel.h"

#include "EQ6ControlPanelDoc.h"
#include "EQ6VersionDlg.h"

#include ".\eq6controlpaneldoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CEQ6ControlPanelDoc

IMPLEMENT_DYNCREATE(CEQ6ControlPanelDoc, CDocument)

BEGIN_MESSAGE_MAP(CEQ6ControlPanelDoc, CDocument)
	ON_COMMAND(ID_COM_COM1, OnComCom1)
	ON_COMMAND(ID_COM_COM2, OnComCom2)
	ON_COMMAND(ID_COM_COM3, OnComCom3)
	ON_COMMAND(ID_COM_COM4, OnComCom4)
	ON_COMMAND(ID_COM_COM5, OnComCom5)
	ON_COMMAND(ID_COM_COM6, OnComCom6)
	ON_BN_CLICKED(IDC_UPDATE_MOUNT, OnBnClickedUpdateMount)
	ON_COMMAND(ID_MOUNTINFORMATION, OnMountinformation)
	ON_COMMAND(ID_COMM_COM7, OnComCom7)
	ON_COMMAND(ID_COMM_COM8, OnComCom8)
	ON_COMMAND(ID_SETTODEFAULT, OnSettodefault)
END_MESSAGE_MAP()


// CEQ6ControlPanelDoc construction/destruction

CEQ6ControlPanelDoc::CEQ6ControlPanelDoc()
: polarLevel(0)
, ledChanged(false)
{
}

CEQ6ControlPanelDoc::~CEQ6ControlPanelDoc()
{
}

BOOL CEQ6ControlPanelDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// Initialise the scope configuration to a useful set of
	// defaults. These are marked as needing to be written
	// to the scope
	miscChanged = 1;

	slew_24_x = FALSE;
	deltaSync = FALSE;
	paddle_0_3_x = FALSE;
	
	trackingChanged = TRUE;
	trackingRate = E_TRK_SIDEREAL;

	raBacklashChanged = TRUE;
	ra.mode = ra.E_BL_NORM;
	ra.steps = 0;

	decBacklashChanged = TRUE;
	dec.mode = dec.E_BL_NORM;
	dec.steps = 0;

	rateChanged = TRUE;
	secsPerRotation[E_TRK_SIDEREAL] = 86164;
	secsPerRotation[E_TRK_SOLAR] = 86400;
	secsPerRotation[E_TRK_LUNAR] = 89309;

	clockFreq = 16000000;		// Standard modification
	stepsPerRotation = 48;		// Standard EQ6
	gearboxRatio = 131.8756;	// Standard EQ6 (later drive)
	return TRUE;
}

// CEQ6ControlPanelDoc serialization

void CEQ6ControlPanelDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// Serialize the telescope configuration data. Store a version
		// to allow later updates to the actual data stored
#define	EQ6_FMT_1	1
#define EQ6_FMT_2	2	// Adds gearbox ratio, periods, 16/8 MHz switch
#define EQ6_FMT_3	3	// Adds polar scope illuminator level

		ar << (WORD)EQ6_FMT_3;

		ar << polarLevel;

		ar << trackingRate;

		ar << slew_24_x;
		ar << paddle_0_3_x;
		ar << deltaSync;
		ar << gearboxRatio;

		ar << secsPerRotation[E_TRK_SIDEREAL];
		ar << secsPerRotation[E_TRK_SOLAR];
		ar << secsPerRotation[E_TRK_LUNAR];

		ar << clockFreq;
		ar << stepsPerRotation;

		ar << ra.mode;
		ar << ra.steps;

		ar << dec.mode;
		ar << dec.steps;
	}
	else
	{
		WORD	format;
		unsigned int	gearbox;
		
		// Restore the data
		ar >> format;
		
		// Process the saved data depending on the format value
		switch(format)
		{
		case EQ6_FMT_1:
			// Restore first format data. Leave undefined entries alone
			ar >> trackingRate;

			ar >> slew_24_x;
			ar >> paddle_0_3_x;
			ar >> deltaSync;
			ar >> gearbox;

			ar >> ra.mode;
			ar >> ra.steps;

			ar >> dec.mode;
			ar >> dec.steps;

			break;

		case EQ6_FMT_3:
			ar >> polarLevel;
			/* FALLTHROUGH */

		case EQ6_FMT_2:
			ar >> trackingRate;

			ar >> slew_24_x;
			ar >> paddle_0_3_x;
			ar >> deltaSync;
			ar >> gearboxRatio;

			ar >> secsPerRotation[E_TRK_SIDEREAL];
			ar >> secsPerRotation[E_TRK_SOLAR];
			ar >> secsPerRotation[E_TRK_LUNAR];

			ar >> clockFreq;
			ar >> stepsPerRotation;

			ar >> ra.mode;
			ar >> ra.steps;

			ar >> dec.mode;
			ar >> dec.steps;

			break;

		default:
			AfxMessageBox("Unknown EQ6 file protocol identifier");
            break;
		}

		// Mark all data as needing to be sent to the scope
		trackingChanged = TRUE;
		rateChanged = TRUE;
		miscChanged = TRUE;
		ledChanged = TRUE;

		raBacklashChanged = TRUE;
		decBacklashChanged = TRUE;
	}
}


// CEQ6ControlPanelDoc diagnostics

#ifdef _DEBUG
void CEQ6ControlPanelDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CEQ6ControlPanelDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG


// CEQ6ControlPanelDoc commands


#define _COM_OPEN_HANDLER(comNum) \
	void CEQ6ControlPanelDoc::OnComCom ## comNum() \
	{ \
		if ( ! serIf.openPort("Com" #comNum)) \
			AfxMessageBox("Error opening port COM" #comNum); \
	}

_COM_OPEN_HANDLER(1)
_COM_OPEN_HANDLER(2)
_COM_OPEN_HANDLER(3)
_COM_OPEN_HANDLER(4)
_COM_OPEN_HANDLER(5)
_COM_OPEN_HANDLER(6)
_COM_OPEN_HANDLER(7)
_COM_OPEN_HANDLER(8)

void CEQ6ControlPanelDoc::OnBnClickedUpdateMount()
{
	serIf.updateFromDoc(this);
}

BOOL CEQ6ControlPanelDoc::isDataChanged(void)
{
	return			miscChanged 
					|| trackingChanged 
					|| raBacklashChanged 
					|| decBacklashChanged
					|| rateChanged;
}

void CEQ6ControlPanelDoc::OnMountinformation()
{
	if ( ! serIf.isOpen())
	{
		AfxMessageBox("Open a com port before fetching mount information");
		return;
	}
	
	CEQ6VersionDlg	versionDlg;

	versionDlg.setSerial(serIf);
	versionDlg.DoModal();
}
void CEQ6ControlPanelDoc::OnSettodefault()
{
	// Set defaults
	OnNewDocument();
	
	// Mark changed
	SetModifiedFlag(TRUE);
}
