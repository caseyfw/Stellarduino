// EQ6VersionDlg.cpp : implementation file
//

#include "stdafx.h"
#include "EQ6ControlPanel.h"
#include "EQ6VersionDlg.h"
#include ".\eq6versiondlg.h"


// EQ6VersionDlg dialog

IMPLEMENT_DYNAMIC(CEQ6VersionDlg, CDialog)
CEQ6VersionDlg::CEQ6VersionDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CEQ6VersionDlg::IDD, pParent)
{
}

CEQ6VersionDlg::~CEQ6VersionDlg()
{
}

void CEQ6VersionDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_NAME, m_name);
	DDX_Control(pDX, IDC_VERSION, m_version);
	DDX_Control(pDX, IDC_DATE, m_date);
}


BEGIN_MESSAGE_MAP(CEQ6VersionDlg, CDialog)
END_MESSAGE_MAP()


// EQ6VersionDlg message handlers

BOOL CEQ6VersionDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Fetch the mount information
	CString*	pDate;
	CString*	pRevision;
	CString*	pName;

	CString		prompt;

	prompt.Format(":GVP#");
	pName = pSerIf->sendCmdGetResponse(prompt);

	prompt.Format(":GVN#");
	pRevision = pSerIf->sendCmdGetResponse(prompt);
	
	prompt.Format(":GVD#");
	pDate = pSerIf->sendCmdGetResponse(prompt);

	// Display the data gathered
	if (pName)
	{
		pName->Trim("#");
		m_name.SetWindowText(*pName);
		delete pName;
	}
	else
		m_name.SetWindowText("<<< No information returned by mount >>>");

	if (pRevision)
	{
		pRevision->Trim("#");
		m_version.SetWindowText(*pRevision);
		delete pRevision;
	}
	else
		m_version.SetWindowText("<<< No information returned by mount >>>");

	if (pDate)
	{
		pDate->Trim("#");
		m_date.SetWindowText(*pDate);
		delete pDate;
	}
	else
		m_date.SetWindowText("<<< No information returned by mount >>>");

	return TRUE;  // return TRUE unless you set the focus to a control
	// EXCEPTION: OCX Property Pages should return FALSE
}

void CEQ6VersionDlg::setSerial(SerialInterface &serIf)
{
	pSerIf = &serIf;
}
