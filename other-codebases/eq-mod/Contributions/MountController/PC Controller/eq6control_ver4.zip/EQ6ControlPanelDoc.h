// EQ6ControlPanelDoc.h : interface of the CEQ6ControlPanelDoc class
//


#pragma once
#include "SerialInterface.h"


typedef struct
{
	enum { E_BL_POS, E_BL_NORM, E_BL_NEG };
		
	WORD			mode;
	unsigned int	steps;		// Backlash steps
} backlash_t;

class CEQ6ControlPanelDoc : public CDocument
{
protected: // create from serialization only
	CEQ6ControlPanelDoc();
	DECLARE_DYNCREATE(CEQ6ControlPanelDoc)

// Attributes
public:
	// Track which parts of the configuration data need to be
	// flushed to the drive
	BOOL	raBacklashChanged;		// RA backlash setting changed
	BOOL	decBacklashChanged;		// DEC backlash setting changed
	BOOL	trackingChanged;		// Tracking parameters changed
	BOOL	miscChanged;			// Other parameter changed
	BOOL	rateChanged;			// Tracking rate divisors changed

	backlash_t		ra;				// RA backlash settings
	backlash_t		dec;			// DEC backlash setting

	BOOL			paddle_0_3_x;	// Paddle 2x does 0.3x
	BOOL			slew_24_x;		// GOTO slew at 24x
	BOOL			deltaSync;		// Sync on long slew
	
	enum
	{
		E_TRK_NONE = -1,			// Tracking disabled
		E_TRK_SIDEREAL = 0,			// Sidereal rate
		E_TRK_SOLAR = 1,			// Solar / planetary rate
		E_TRK_LUNAR = 2				// Lunar tracking rate
	};

	unsigned long	secsPerRotation[3];	// Axis rotation period (sec)
	unsigned long	clockFreq;			// Mod xtal freq
	unsigned int	stepsPerRotation;	// Stepper steps per rotn
	double			gearboxRatio;		// Gearbox divisor

	WORD	trackingRate;
// Operations
public:

// Overrides
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);

// Implementation
public:
	virtual ~CEQ6ControlPanelDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	DECLARE_MESSAGE_MAP()
public:	
	afx_msg void OnComCom1();
	afx_msg void OnComCom2();
	afx_msg void OnComCom3();
	afx_msg void OnComCom4();
	afx_msg void OnComCom5();
	afx_msg void OnComCom6();
	afx_msg void OnBnClickedUpdateMount();
	BOOL isDataChanged(void);

	SerialInterface	serIf;
public:
	afx_msg void OnMountinformation();
	afx_msg void OnComCom7();
	afx_msg void OnComCom8();
	afx_msg void OnSettodefault();
	unsigned int polarLevel;
	bool ledChanged;
};


