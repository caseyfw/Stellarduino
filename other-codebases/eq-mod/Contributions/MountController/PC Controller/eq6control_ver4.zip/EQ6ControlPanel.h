// EQ6ControlPanel.h : main header file for the EQ6ControlPanel application
//
#pragma once

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols


// CEQ6ControlPanelApp:
// See EQ6ControlPanel.cpp for the implementation of this class
//

class CEQ6ControlPanelApp : public CWinApp
{
public:
	CEQ6ControlPanelApp();


// Overrides
public:
	virtual BOOL InitInstance();

// Implementation
	afx_msg void OnAppAbout();
	DECLARE_MESSAGE_MAP()
};

extern CEQ6ControlPanelApp theApp;