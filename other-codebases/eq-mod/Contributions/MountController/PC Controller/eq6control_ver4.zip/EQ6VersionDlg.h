#pragma once

#include "SerialInterface.h"
#include "afxwin.h"


// EQ6VersionDlg dialog

class CEQ6VersionDlg : public CDialog
{
	DECLARE_DYNAMIC(CEQ6VersionDlg)

public:
	CEQ6VersionDlg(CWnd* pParent = NULL);   // standard constructor
	virtual ~CEQ6VersionDlg();

// Dialog Data
	enum { IDD = IDD_MOUNT_VERSION };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support

	DECLARE_MESSAGE_MAP()
public:
	virtual BOOL OnInitDialog();
	void setSerial(SerialInterface &serIf);

private:
	SerialInterface*	pSerIf;
public:
	CEdit m_name;
	CEdit m_version;
	CEdit m_date;
};
