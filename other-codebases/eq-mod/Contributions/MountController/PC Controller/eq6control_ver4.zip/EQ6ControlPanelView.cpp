// EQ6ControlPanelView.cpp : implementation of the CEQ6ControlPanelView class
//

#include "stdafx.h"
#include "EQ6ControlPanel.h"

#include "EQ6ControlPanelDoc.h"
#include "EQ6ControlPanelView.h"
#include ".\eq6controlpanelview.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CEQ6ControlPanelView

IMPLEMENT_DYNCREATE(CEQ6ControlPanelView, CFormView)

BEGIN_MESSAGE_MAP(CEQ6ControlPanelView, CFormView)
ON_BN_CLICKED(IDC_TRK_NONE, OnBnClickedTrk)
ON_BN_CLICKED(IDC_TRK_SIDEREAL, OnBnClickedTrk)
ON_BN_CLICKED(IDC_TRK_SOLAR, OnBnClickedTrk)
ON_BN_CLICKED(IDC_TRK_LUNAR, OnBnClickedTrk)
ON_BN_CLICKED(IDC_RA_FIN_POS, OnBnClickedRa)
ON_BN_CLICKED(IDC_RA_FIN_NEG, OnBnClickedRa)
ON_BN_CLICKED(IDC_RA_NORMAL, OnBnClickedRa)
ON_BN_CLICKED(IDC_DEC_FIN_POS, OnBnClickedDec)
ON_BN_CLICKED(IDC_DEC_FIN_NEG, OnBnClickedDec)
ON_BN_CLICKED(IDC_DEC_NORMAL, OnBnClickedDec)
ON_BN_CLICKED(IDC_M_DELTA, OnBnClickedMDelta)
ON_BN_CLICKED(IDC_M_GOTO, OnBnClickedMGoto)
ON_BN_CLICKED(IDC_M_PADDLE, OnBnClickedMPaddle)
ON_EN_KILLFOCUS(IDC_RA_STEPS, OnEnKillfocusRaSteps)
ON_EN_KILLFOCUS(IDC_DEC_STEPS, OnEnKillfocusDecSteps)
ON_EN_KILLFOCUS(IDC_HW_STEPS, OnEnKillfocusHwSteps)
ON_BN_CLICKED(IDC_HW_16MHZ, OnBnClickedHw16mhz)
ON_BN_CLICKED(IDC_HW_8MHZ, OnBnClickedHw16mhz)
ON_EN_KILLFOCUS(ID_M_SIDEREAL, OnEnKillfocusMSidereal)
ON_EN_KILLFOCUS(ID_M_SOLAR, OnEnKillfocusMSolar)
ON_EN_KILLFOCUS(ID_M_LUNAR, OnEnKillfocusMLunar)
ON_COMMAND(ID_SETTODEFAULT, OnSettodefault)

ON_NOTIFY(NM_RELEASEDCAPTURE, IDC_POLAR_LEVEL, OnNMReleasedcapturePolarLevel)

ON_CBN_KILLFOCUS(IDC_GB_COMBO, OnCbnKillfocusGbCombo)
END_MESSAGE_MAP()

// CEQ6ControlPanelView construction/destruction

CEQ6ControlPanelView::CEQ6ControlPanelView()
	: CFormView(CEQ6ControlPanelView::IDD)
	, m_clockFreqButton(0)
	, bRedrawing(FALSE)
{
	bRedrawing = FALSE;
}

CEQ6ControlPanelView::~CEQ6ControlPanelView()
{
}

void CEQ6ControlPanelView::DoDataExchange(CDataExchange* pDX)
{
	CFormView::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_RA_STEPS, m_raSteps);
	DDX_Control(pDX, IDC_DEC_STEPS, m_decSteps);
	DDX_Control(pDX, IDC_M_DELTA, m_delta);
	DDX_Control(pDX, IDC_M_GOTO, m_goto);
	DDX_Control(pDX, IDC_M_PADDLE, m_paddle);

	DDX_Radio(pDX, IDC_TRK_NONE, m_trkButton);
	DDX_Radio(pDX, IDC_RA_FIN_POS, m_raButton);
	DDX_Radio(pDX, IDC_DEC_FIN_POS, m_decButton);
	DDX_Control(pDX, IDC_HW_STEPS, m_stepsRotn);
	DDX_Radio(pDX, IDC_HW_16MHZ, m_clockFreqButton);
	DDX_Control(pDX, ID_M_SOLAR, m_solarPeriod);
	DDX_Control(pDX, ID_M_LUNAR, m_lunarPeriod);
	DDX_Control(pDX, ID_M_SIDEREAL, m_siderealPeriod);
	DDX_Control(pDX, IDC_POLAR_LEVEL, m_polarLevel);
	DDX_Control(pDX, IDC_GB_COMBO, m_gearbox);
}

BOOL CEQ6ControlPanelView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CFormView::PreCreateWindow(cs);
}

void CEQ6ControlPanelView::OnInitialUpdate()
{
	CFormView::OnInitialUpdate();
	GetParentFrame()->RecalcLayout();
	ResizeParentToFit();
}


// CEQ6ControlPanelView diagnostics

#ifdef _DEBUG
void CEQ6ControlPanelView::AssertValid() const
{
	CFormView::AssertValid();
}

void CEQ6ControlPanelView::Dump(CDumpContext& dc) const
{
	CFormView::Dump(dc);
}

CEQ6ControlPanelDoc* CEQ6ControlPanelView::GetDocument() const // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CEQ6ControlPanelDoc)));
	return (CEQ6ControlPanelDoc*)m_pDocument;
}
#endif //_DEBUG


// CEQ6ControlPanelView message handlers


void CEQ6ControlPanelView::OnDraw(CDC* /*pDC*/)
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	bRedrawing = TRUE;
	
	// Update the view with information from the data structure

	// Update tracking rate
	switch(pDoc->trackingRate)
	{
	case pDoc->E_TRK_NONE:		m_trkButton = 0; break;
	case pDoc->E_TRK_SIDEREAL:	m_trkButton = 1; break;
	case pDoc->E_TRK_SOLAR:		m_trkButton = 2; break;
	case pDoc->E_TRK_LUNAR:		m_trkButton = 3; break;
	default:
		// Oops!
		TRACE0(_T("Bad tracking button"));
		break;
	}

	// Update misc items
	m_delta.SetCheck(pDoc->deltaSync);
	m_goto.SetCheck(pDoc->slew_24_x);
	m_paddle.SetCheck(pDoc->paddle_0_3_x);

	CString		str;

	str.Format("%.4f", pDoc->gearboxRatio);
	m_gearbox.SetWindowText(str);

	// Update RA
	switch (pDoc->ra.mode)
	{
	case pDoc->ra.E_BL_POS:		m_raButton = 0; break;
	case pDoc->ra.E_BL_NORM:	m_raButton = 1; break;
	case pDoc->ra.E_BL_NEG:		m_raButton = 2; break;
	default:
		// Oops!
		TRACE0(_T("Bad RA button"));
		break;
	}

	str.Format("%d", pDoc->ra.steps);
	m_raSteps.SetWindowText(str);

	// Update DEC
	switch (pDoc->dec.mode)
	{
	case pDoc->dec.E_BL_POS:	m_decButton = 0; break;
	case pDoc->dec.E_BL_NORM:	m_decButton = 1; break;
	case pDoc->dec.E_BL_NEG:	m_decButton = 2; break;
	default:
		// Oops!
		TRACE0(_T("Bad DEC button"));
		break;
	}

	str.Format("%d", pDoc->dec.steps);
	m_decSteps.SetWindowText(str);

	// Update rotation periods
	str.Format("%lu", pDoc->secsPerRotation[pDoc->E_TRK_SIDEREAL]);
	m_siderealPeriod.SetWindowText(str);
	str.Format("%lu", pDoc->secsPerRotation[pDoc->E_TRK_SOLAR]);
	m_solarPeriod.SetWindowText(str);
	str.Format("%lu", pDoc->secsPerRotation[pDoc->E_TRK_LUNAR]);
	m_lunarPeriod.SetWindowText(str);

	// Update steps per rotation
	str.Format("%d", pDoc->stepsPerRotation);
	m_stepsRotn.SetWindowText(str);

	// Update frequency
	switch (pDoc->clockFreq)
	{
	case 16000000:		m_clockFreqButton = 0; break;
	case 8000000:		m_clockFreqButton = 1; break;
	default:
		// Oops!
		TRACE0(_T("Bad clock freq"));
		break;
	}

	m_polarLevel.SetPos(((int)pDoc->polarLevel * 100) / 255);

	// Update buttons handled by DDX
	UpdateData(FALSE);

	// Do processing for 'update mount' button
	updateGlobal(FALSE);

	bRedrawing = FALSE;
}

void CEQ6ControlPanelView::OnBnClickedTrk()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	// Update the variables associated with the radio buttons
	UpdateData(TRUE);

	switch(m_trkButton)
	{
	case 0:		pDoc->trackingRate = pDoc->E_TRK_NONE; break;
	case 1:		pDoc->trackingRate = pDoc->E_TRK_SIDEREAL; break;
	case 2:		pDoc->trackingRate = pDoc->E_TRK_SOLAR; break;
	case 3:		pDoc->trackingRate = pDoc->E_TRK_LUNAR; break;
	default:
		// Oops!
		TRACE0(_T("Bad tracking click"));
		break;
	}

	// Mark tracking as needing update
	pDoc->trackingChanged = TRUE;
	updateGlobal(TRUE);
}

void CEQ6ControlPanelView::OnBnClickedRa()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();
	UpdateBacklashButton(m_raButton, pDoc->ra);
	pDoc->raBacklashChanged = TRUE;
	updateGlobal(TRUE);
}

void CEQ6ControlPanelView::OnBnClickedDec()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();
	UpdateBacklashButton(m_decButton, pDoc->dec);
	pDoc->decBacklashChanged = TRUE;
	updateGlobal(TRUE);
}

VOID CEQ6ControlPanelView::UpdateBacklashButton(int& button, backlash_t& backlash)
{
	// Update the value of the button variables
	UpdateData(TRUE);

	// Set the variable
	switch(button)
	{
	case 0:		backlash.mode = backlash_t.E_BL_POS; break;
	case 1:		backlash.mode = backlash_t.E_BL_NORM; break;
	case 2:		backlash.mode = backlash_t.E_BL_NEG; break;
	default:
		// Oops!
		TRACE0(_T("Bad backlash click"));
		break;
	}
}

void CEQ6ControlPanelView::OnBnClickedMDelta()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	pDoc->deltaSync = m_delta.GetCheck() == BST_CHECKED;
	pDoc->miscChanged = TRUE;
	updateGlobal(TRUE);
}

void CEQ6ControlPanelView::OnBnClickedMGoto()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	pDoc->slew_24_x = m_goto.GetCheck() == BST_CHECKED;
	pDoc->miscChanged = TRUE;
	updateGlobal(TRUE);
}

void CEQ6ControlPanelView::OnBnClickedMPaddle()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	pDoc->paddle_0_3_x = m_paddle.GetCheck() == BST_CHECKED;
	pDoc->miscChanged = TRUE;
	updateGlobal(TRUE);
}

void CEQ6ControlPanelView::OnCbnKillfocusGbCombo()
{
	CString					str;
	double					newValue;
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	if (bRedrawing)
		return;

	// Get the value of the control
	m_gearbox.GetWindowText(str);

	newValue = strtod(str.GetString(), 0);

	if (newValue < 1 || newValue > 255)
	{
		AfxMessageBox("Illegal gearbox ratio - expected 1..255");

		CString	oldStr;
		oldStr.Format("%f", pDoc->gearboxRatio);

		m_gearbox.SetWindowText(oldStr);
	}
	else if (pDoc->gearboxRatio != newValue)
	{
		updateGlobal(TRUE);
		pDoc->rateChanged = TRUE;
        pDoc->gearboxRatio = newValue;
	}
}

void CEQ6ControlPanelView::OnEnKillfocusRaSteps()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	if (bRedrawing)
		return;

	if (UpdateBacklashValue(m_raSteps, pDoc->ra))
	{
		pDoc->raBacklashChanged = TRUE;
		updateGlobal(TRUE);
	}
}

void CEQ6ControlPanelView::OnEnKillfocusDecSteps()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	if (bRedrawing)
		return;

	if (UpdateBacklashValue(m_decSteps, pDoc->dec))
	{
		pDoc->decBacklashChanged = TRUE;
		updateGlobal(TRUE);
	}
}

BOOL CEQ6ControlPanelView::UpdateBacklashValue(CEdit & editCtrl, backlash_t & backlash)
{
	CString	str;
	int		newValue;

	// Get the value of the control
	editCtrl.GetWindowText(str);

	newValue = atoi(str.GetString());

	if (newValue < 0 || newValue > 65535)
	{
		AfxMessageBox("Illegal backlash setting - expected 0..65535");

		CString	oldStr;
		oldStr.Format("%d", backlash.steps);

		editCtrl.SetWindowText(oldStr);
	}
	else if (backlash.steps != newValue)
	{
		backlash.steps = newValue;
		return TRUE;
	}

	// If we get here the value wasn't changed
	return FALSE;
}
void CEQ6ControlPanelView::updateGlobal(BOOL bModified)
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	// Update document modified flag
	if (bModified)
		pDoc->SetModifiedFlag(TRUE);

	// Update the 'update mount' button
	//CWnd*	pWnd;
	//
	//pWnd = GetDlgItem(IDC_UPDATE_MOUNT);
	//pWnd->EnableWindow(pDoc->isDataChanged());
}

void CEQ6ControlPanelView::OnEnKillfocusHwSteps()
{
	CString	str;
	int		newValue;
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	if (bRedrawing)
		return;

	// Get the value of the control
	m_stepsRotn.GetWindowText(str);

	newValue = atoi(str.GetString());

	if (newValue < 48 || newValue > 480)
	{
		AfxMessageBox("Illegal steps/rotn - expected 48 .. 480");

		CString	oldStr;
		oldStr.Format("%d", pDoc->stepsPerRotation);

		m_stepsRotn.SetWindowText(oldStr);
	}
	else if (pDoc->stepsPerRotation != newValue)
	{
		updateGlobal(TRUE);
		pDoc->rateChanged = TRUE;
        pDoc->stepsPerRotation = newValue;
	}	// TODO: Add your control notification handler code here
}

BOOL CEQ6ControlPanelView::UpdatePeriodValue(CEdit & editCtrl, unsigned long &secsPerRotation)
{
	CString	str;
	unsigned int		newValue;

	// Get the value of the control
	editCtrl.GetWindowText(str);

	newValue = atoi(str.GetString());

	if (newValue < 10000 || newValue > 1000000)
	{
		AfxMessageBox("Illegal rotation period setting - expected 10000 .. 100000");

		CString	oldStr;
		oldStr.Format("%d", secsPerRotation);

		editCtrl.SetWindowText(oldStr);
	}
	else if (secsPerRotation != newValue)
	{
		secsPerRotation = newValue;
		return TRUE;
	}

	// If we get here the value wasn't changed
	return FALSE;
}

void CEQ6ControlPanelView::OnEnKillfocusMSidereal()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	if (bRedrawing)
		return;

	if (UpdatePeriodValue(m_siderealPeriod, pDoc->secsPerRotation[pDoc->E_TRK_SIDEREAL]))
	{
		pDoc->rateChanged = TRUE;
		updateGlobal(TRUE);
	}
}

void CEQ6ControlPanelView::OnEnKillfocusMSolar()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	if (bRedrawing)
		return;

	if (UpdatePeriodValue(m_solarPeriod, pDoc->secsPerRotation[pDoc->E_TRK_SOLAR]))
	{
		pDoc->rateChanged = TRUE;
		updateGlobal(TRUE);
	}
}

void CEQ6ControlPanelView::OnEnKillfocusMLunar()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	if (bRedrawing)
		return;

	if (UpdatePeriodValue(m_lunarPeriod, pDoc->secsPerRotation[pDoc->E_TRK_LUNAR]))
	{
		pDoc->rateChanged = TRUE;
		updateGlobal(TRUE);
	}
}

void CEQ6ControlPanelView::OnBnClickedHw16mhz()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();
	
	// Update the variables associated with the radio buttons
	UpdateData(TRUE);

	// Set the variable
	switch(m_clockFreqButton)
	{
	case 0:		pDoc->clockFreq = 16000000; break;
	case 1:		pDoc->clockFreq = 8000000; break;
	default:
		// Oops!
		TRACE0(_T("Bad clock frequency click"));
		break;
	}

	pDoc->rateChanged = TRUE;
	updateGlobal(TRUE);// Update the value of the button variables
}


void CEQ6ControlPanelView::OnSettodefault()
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();

	// Set document to default
	pDoc->OnSettodefault();

	// Update view
	OnDraw(0);


// TODO: Add your command handler code here
}

void CEQ6ControlPanelView::OnNMReleasedcapturePolarLevel(NMHDR *pNMHDR, LRESULT *pResult)
{
	CEQ6ControlPanelDoc *	pDoc = GetDocument();
	
	pDoc->polarLevel = (m_polarLevel.GetPos() * 255) / 100;

	pDoc->ledChanged = TRUE;
	updateGlobal(TRUE);// Update the value of the button variables
	
	// Update the mount
	pDoc->serIf.updatePolar(pDoc->polarLevel);

	*pResult = 0;
}
