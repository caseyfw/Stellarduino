/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: eq6.c,v 1.13 2004/12/07 06:36:27 dbh Exp $
 */

#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/io.h>

#include "eq6.h"
#include "paddle.h"
#include "stepper.h"
#include "driver.h"
#include "serial.h"
#include "pguide.h"
#include "sr.h"
#include "goto.h"
#include "polar.h"
#include "combine.h"

volatile uint32_t    idleCtr;

#if 1
void
putch(char ch)
{
    while (! (UCSR1A & 0x20))
        ;
    UDR1 = ch;
}

void
putstr(char *pStr)
{
    while (*pStr)
        putch(*pStr++);
}

SIGNAL(__vector_default)
{
    putstr("*** Unhandled int ***");
    for (;;)
         ;
}


#endif
/* main() is called after the basic system initialization. This 
 * initialises the program modules (these are, generally, interrupt
 * driver), and then waits for the end of civilization as we know it
 *
 * Passed:
 *     Nothing
 *
 * Returns:
 *     Nothing
 *
 * Notes:
 *     There is little to do here but wait.
 */
int
main(void)
{
    DDRA = 0xff;
    DDRC = 0xff;
    PORTA = 0x0;
    PORTC = 0x0;

    /* Initialize the modules */
    serialInit();               // Initialize serial port first for debug
    paddleInit();
    stepperInit();
    driverInit();
    pguideInit();
    gotoInit();
    polarInit();

    /* Load save data (if any) from the EEPROM */
    if (srLoadState())
        serialTx("*** EEPROM ERROR ***");

    /* Use saved transmission ratio information */
    setTrackRate(trackingRate);

    /* Start timer2. This is used to generate a 10ms (100 Hz) clock for
     * the parallel guiding debounce and the goto code.
     *
     * The activities are not timing critical, so a 8-bit timer is used.
     * There is an error of less than 0.5% associated with this.
     */
    OCR2 = (CLK_RATE / 1024 / TMR2_FREQ) - 1;
    TCCR2 = _BV(WGM21) | _BV(CS22) | _BV(CS21) | _BV(CS20);

    /* Enable interrupt generation from timer 2 */
    TIMSK |= _BV(OCIE2);

    /* Enable interrupts */
    sei();

    /* Increment the idle counter to get some idea of the system
     * idle time
     */
    for (;;)
    {
        srSaveState();
        rxProcessing();
    }

    /* NOTREACHED */
    return 0;
}


/* The following timer handles TIMER 2 interrupts. Several functions use this
 * 10 ms timer for time keeping functions
 */
SIGNAL(SIG_OUTPUT_COMPARE2)
{
    pguideInt();
    gotoInt();

    /* Decrement the step counter in the excitation entry. This is used
     * to time relay state changes
     */
    if (raExcitation.counter > 0)
        --raExcitation.counter;
    if (decExcitation.counter > 0)
        --decExcitation.counter;

    /* Update the pulseguide timers (if runnning) */
#define TMR2_MS (1000 / TMR2_FREQ)
    if (raPulseTime > 0)
    {
        // Update timer
        if (raPulseTime > TMR2_MS)
            raPulseTime -= TMR2_MS;
        else
        {
            raPulseTime = 0;
            rateInput.serialRaRate = SPEED_0_X;
            updateMountSpeed();
        }
    }
        
    if (decPulseTime > 0)
    {
        // Update timer
        if (decPulseTime > TMR2_MS)
            decPulseTime -= TMR2_MS;
        else
        {
            decPulseTime = 0;
            rateInput.serialDecRate = SPEED_0_X;
            updateMountSpeed();
        }
    }
}
