/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: serial.c,v 1.21 2005/12/11 20:13:02 dbh Exp $
 */

#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>     // atoi()

#include "eq6.h"
#include "serial.h"
#include "combine.h"
#include "stepper.h"
#include "paddle.h"
#include "sr.h"
#include "goto.h"
#include "polar.h"

/* This file accepts serial data from a serial guider and performs the
 * requested guiding operation.
 *
 * This interface is also is designed to support future mount management
 * operations via the same serial interface
 *
 * The current protocol is:
 *
 * [0-9]    Add the number to the "accumulator"
 * -        Denote accumulator as negative
 * #        Clear the accumulator and flag
 * <        Clear the flag
 * >        Set the flag
 * U        Copy flag state to the DEC UP key
 * D        Copy flag state to the DEC DOWN key
 * L        Copy flag state to the RA left key
 * R        Copy flag state to the RA right key
 * C        Release all keys
 *
 * B        Set DEC backlash to accum
 * M        Set DEC backlash mode (+ = finish pos, 0 = none, - = finish neg)
 * b        Set RA backlash to accum
 * m        Set RA backlash mode (see DEC backlash)
 *
 * O        Reverse DEC motion if flag set
 * o        Reverse RA motion if flag set
 *
 * G        Set 2X paddle to guiding speed (0.3x) if flag set, 1X if clear
 *
 * S        Set the slewing speed used for GOTO (TRUE = 24x, FALSE = 16x)
 *
 * t        Use halfStep for slow step if flag set, microStep if clear (TEST)
 *
 * T        Set the tracking rate as-per the accumulator
 *          -1 = No tracking (Terrestial)
 *          0 = Sidereal
 *          1 = Solar / Planetary
 *          2 = Lunar
 *
 * P        Set the polar scope illumination level from accum 0..255
 *
 * g        Set transmission (gearbox) ratio [retired - no operation]
 *
 * c        Set "cursor" position for tracking table update to accumulator
 * s        Set divisor for tracking rate clock @'cursor' to accumulator
 * a        Set adjustment (one tick [+]dropped/[-]added every accum ticks)
 * p        Set 360deg rotation time for tracking entry
 *
 * d        Set delta sync enable as per flag
 *
 * The '#' and accumulator support future value-based entries
 *
 * A subset of LX200 commands are supported for compatibility
 * with various autoguiding programs.
 *
 * :Me# :Mw# :Ms# :Mn#          Start slewing East(right), West(left),
 *                              North (up), South (down)
 * :Qe# :Qw# :Qs# :Qn# :Q#      Halt selected or all slews
 * :RG# :RC# :RM# :RS#          Set guiding rate for LX200 motions
 *                              G = 0.3x
 *                              C = 1x
 *                              M = 8x
 *                              S = 16x
 * :Mg[snew]nnnn#               Pulseguide. Move in specified direction
 *                              for nnnn milliseconds and return to
 *                              tracking (for RA) or stop (for DEC).
 *
 *                              Conflicting movements are resolved (per axis)
 *                              by the later command overriding the earlier
 *                              one.
 *                                      
 * ACK                          Returns alignment mode (always 'P' polar)
 *
 * :GVD# :GVN# :GVP# :GVT:      Identification info
 *
 * A subset of the LX200 commands are supported for GOTO support
 *
 * :GD#                         Get DEC from mount in sDD*HH# or sDD*HH'SS#
 *                              form (depends on :U# output precision)
 * :GR#                         Get RA from mount in HH:MM.T# or HH:MM:SS#
 *                              form (depends on :U# output precision)
 * :U#                          Toggle output precision
 *
 * :SdsDD*MM#                   Set DEC of next GOTO
 * :SdsDD*MM:SS#                Set DEC of next GOTO
 *
 * :SrHH:MM.T#                  Set RA of next GOTO
 * :SrHH:MM.SS#                 Set RA of next GOTO
 *
 * :MS#                         Execute the GOTO.
 * :CM#                         Sync scope to current position
 */
#include <avr/signal.h>
#include <inttypes.h>

#include "paddle.h"
#include "eq6.h"
#include "combine.h"

volatile uint16_t raPulseTime;
volatile uint16_t decPulseTime;

/* serialInit() initializes the serial port used for the 
 * serial guider input.
 *
 * Passed:
 *         Nothing
 *
 * Returns:
 *         Nothing.
 */
void
serialInit(void)
{
    // The serial guider is attached to USART1

    // Set serial rate
    UBRR1H = (CLK_RATE / GUIDE_BAUD / 16 - 1) >> 8;
    UBRR1L = (CLK_RATE / GUIDE_BAUD / 16 - 1) & 0xff;

    /* Setup registers
     * 8 bits, no parity, RX enable, TX enable. Only the Rx interrupts are
     * enabled at this point.
     */
    UCSR1B = 0;            // Disable all interrupts
    UCSR1C = _BV(URSEL1) | _BV(UCSZ11) | _BV(UCSZ10);
    UCSR1B = _BV(RXCIE1) | _BV(RXEN1) | _BV(TXEN1);
}

#define MAX_TX_QUEUED   64
static char             txQueue[MAX_TX_QUEUED];
unsigned char           txQWr;
unsigned char           txQRd;

/* serialTx() is called to send a string of characters on the scope UART
 *
 * Passed:
 *      pStr            Null-terminated string to send
 *
 * Returns:
 *      0               All OK
 *      non-zero        String alread being sent
 */
char
serialTx(char *pStr)
{
    unsigned char       newWritePos = txQWr;
    char                startTx = (txQWr == txQRd);

    // Copy characters into the transmit queue.
    while (*pStr != 0)
    {
        txQueue[newWritePos] = *pStr++;
        newWritePos = (newWritePos + 1) % MAX_TX_QUEUED;

        // If we get full then return and drop the whole string
        if (newWritePos == txQRd)
            return 1;
    }

    // Ok, update the write pointer
    txQWr = newWritePos;

    // Enable the transmitter
    if (startTx)
    {
        // Send a character
        UDR1 = txQueue[txQRd];
        txQRd = (txQRd + 1) % MAX_TX_QUEUED;
        
	// Enable Tx interrupts
        UCSR1B |= _BV(TXCIE1);
    }
    
    return 0;
}

/* serialTxInt() is called whenever a character needs to be sent.
 *
 * Passed:
 *      Nothing
 *
 * Returns:
 *      Nothing
 *
 * Notes:
 *      The UART generates a interrupt whenever it wants another character.
 *      If there are no characters to send we just disable the interrupt
 */
SIGNAL(SIG_USART1_TRANS)
{
    // See if there are characters in the queue
    if (txQWr == txQRd)
    {
        // No characers - kill interrupts
        UCSR1B &= ~_BV(TXCIE1);
        return;
    }
    else
    {
        // Characters to send - send one!
        UDR1 = txQueue[txQRd];

        // Increment pointer
        txQRd = (txQRd + 1) % MAX_TX_QUEUED;
    }
}


#define MAX_RX_QUEUED   64
static char             rxQueue[MAX_RX_QUEUED];
unsigned char           rxQWr;
unsigned char           rxQRd;

/* serialRxInt() is called whenever a character is received on USART1.
 * These characters are placed into a queue for later processing
 *
 * Passed:
 *         Nothing
 *
 * Returns:
 *         Nothing
 *
 * Notes:
 *         Interrupts are disabled during processing
 */
SIGNAL(SIG_USART1_RECV)
{
    uint8_t             ch;
    unsigned char       newRxQWr;

    /* Get the character from the port. This will dismiss the interrupt
     */
    ch = UDR1;

    /* Push it into the RX queue */
    rxQueue[rxQWr] = ch;

    /* Update pointer if there was room */
    newRxQWr = (rxQWr + 1) % MAX_RX_QUEUED;
    if (newRxQWr != rxQRd)
        rxQWr = newRxQWr;
    else
        UDR1 = '!';
}
    
/* rxProcessing() is called to process any received characters in the
 * queue.
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
rxProcessing(void)
{
    /* Variables for flags/accumulator */
    static uint8_t      flag = 0;
    static uint32_t     accum = 0;
    static uint8_t      signNeg = 0;
    static uint16_t     cursor = (uint16_t)-1;

    /* Variable holding current guiding rate */
    static int8_t       guideRate = SPEED_0_33_X;

    /* Flags holding current requested slewing directions */
    static uint8_t      upFlag;
    static uint8_t      downFlag;
    static uint8_t      leftFlag;
    static uint8_t      rightFlag;

    /* LX200 command state */
#define LX200_CMD_LEN   16
    static char         lxCmd[LX200_CMD_LEN];
    static uint8_t      lxPos;

    uint8_t             ch;
    uint8_t             raChg = 0;              // RA direction changed
    uint8_t             decChg = 0;             // DEC direction changed
    uint8_t             timed = 0;              // Change is timed move

    static uint8_t      lxMode;

    /* Get the character from the queue. If there is no character then
     * stop processing
     */
    if (rxQRd == rxQWr)
        return;

    ch = rxQueue[rxQRd];
    rxQRd = (rxQRd + 1) % MAX_RX_QUEUED;
    
    /* This code processes commands when a LX200 command is not currently
     * being processed.
     */
    if (lxMode == 0)
    {
        switch(ch)
        {
        case '0' ... '9':
            /* Add it to the accumulator */
            accum = (accum * 10) + ch - '0';
            break;

        case '#':
            /* Clear the accumulator */
            accum = 0;
            signNeg = 0;
            break;

        case '-':
            /* Set the sign of the accumulator to negative */
            signNeg = 1;
            break;

        case '<':
            /* Clear the flag */
            flag = 0;
            break;

        case '>':
            /* Set the flag */
            flag = 1;
            break;

        case 'U':
            /* Guide UP (DEC) */
            upFlag = flag;
            decChg = 1;
            break;

        case 'D':
            /* Guide DOWN (DEC) */
            downFlag = flag;
            decChg = 1;
            break;

        case 'R':
            /* Guide RIGHT (RA) */
            rightFlag = flag;
            raChg = 1;
            break;

        case 'L':
            /* Guide LEFT (RA) */
            leftFlag = flag;
            raChg = 1;
            break;

        case 'C':
            /* Clear all keys */
            upFlag = downFlag = leftFlag = rightFlag = 0;
            raChg = decChg = 1;
            break;

        case 'b':
            /* Set RA backlash steps */
            raState.backlash = accum;
            doSave = 1;
            break;

        case 'B':
            /* Set DEC backlash steps */
            decState.backlash = accum;
            doSave = 1;
            break;

        case 'm':
            /* Set RA backlash mode */
            raState.finNeg = raState.finPos = 0;
            if (accum != 0)
            {
                if (signNeg)
                    raState.finNeg = 1;
                else
                    raState.finPos = 1;
            }
            doSave = 1;
            break;

        case 'M':
            /* Set DEC backlash mode */
            decState.finNeg = decState.finPos = 0;
            if (accum != 0)
            {
                if (signNeg)
                    decState.finNeg = 1;
                else
                    decState.finPos = 1;
            }
            doSave = 1;
            break;
        
        case 'o':      /* Reverse RA direction */
            raState.dir = flag ? -1 : 1;
            doSave = 1;
            break;

        case 'O':      /* Reverse DEC direction */
            decState.dir = flag ? -1 : 1;
            doSave = 1;
            break;

        case 'G':
            /* Set the speed for the 2x paddle button. This has
             * no effect on the rate used for serial commands
             */
            paddleGuideRate = flag ? SPEED_0_33_X : SPEED_1_X;
            doSave = 1;
            break;

        case 'T':
            /* Set the tracking speed */
            setTrackRate(signNeg ? -accum : accum);
            doSave = 1;
            break;

        case 'g':       /* Set transmission (gearbox) ratio */
            // This command has been retired - do nothing
            break;

        case 'P':       /* Set polar scope illumination level */
            polarLevel = (accum < 256) ? accum : 255;
            doSave = 1;
            break;

        case 'c':       /* Set cursor to accumulator */
            cursor = accum;
            break;

        case 's':       /* Set rate divisor for tracking rate 'cursor' */
            if (cursor < NUM_RATES)
            {
                trackRateTable[cursor].div = accum;
                doSave = 1;
            }
            break;

        case 'a':       /* Set adjustment for tracking rate 'cursor' */
            if (cursor < NUM_RATES)
            {
                trackRateTable[cursor].adj = accum;
                trackRateTable[cursor].doDropInt = ! signNeg;
                doSave = 1;
            }
            break;

        case 'p':       /* Set period for tracking rate 'cursor' */
            if (cursor < NUM_RATES)
            {
                trackRateTable[cursor].secsPerRotation = accum;
                doSave = 1;
            }
            break;

        case 'S':       /* Get GOTO slewing speed */
            if (flag)
            {
                /* Use the faster GOTO speed. This is the default. Use
                 * this instead of the slow rate if the mount can handle it
                 */
                gotoRate = 24;
                gotoSpeed = SPEED_24_X;
            }
            else
            {
                /* Use a slower GOTO slew rate. This may be necessary if
                 * the mount if heavily loaded, or badly balanced
                 */
                gotoRate = 16;
                gotoSpeed = SPEED_16_X;
            }
            doSave = 1;
            break;

        case 'd':      /* Control delta sync */
            gotoDeltaSync = flag;
            doSave = 1;
            break;

        case 't':
            /* *TEST* Allow half step table to be specified instead of
             * the microstep table
             */
            doHalfStep = flag;
            break;

        case '\006':        /* LX200: ACK */
            serialTx("P");
            break;

        case ':':           /* LX200: Start command */
            /* This indicates the start of a LX200 command */
            lxMode = 1;
            lxPos = 0;
            break;

        default:
            /* OK, now we're confused .... */
            UDR1 = '?';
            break;
        }
    }
    else
    {
        /* This section of code supports the LX200 commands. They
         * have a fundimentally different syntax to the existing
         * commands, so they are implemented in this code seperately
         * for clarity.
         */
        if (ch != '#')
        {
            /* Add this to the command characters so far */
            lxCmd[lxPos++] = ch;
            if (lxPos == LX200_CMD_LEN)
            {
                /* Too much data for any command */
                UDR1 = '?';
                lxMode = 0;
            }
        }
        else
        {
            /* We are going back to native mode after this */
            lxMode = 0;

            if (lxPos >= 1)
            {
                /* We have a complete LX200 command (without the delimiters).
                 * Do what it asks
                 */
                switch(lxCmd[0])
                {

                case 'C':       // Sync commands
                    if (lxPos == 2 && lxCmd[1] == 'M')
                    {
                         gotoSync(1);
                    }
                    else
                        UDR1 = '?';
                    break;

                case 'G':       // Get mount position information
                    if (lxPos == 2)
                    {
                        // We have the right #chars - do it
                        switch (lxCmd[1])
                        {
                        case 'D':       // Get current scope DEC
                            gotoOutputDec();
                            break;
                            
                        case 'R':       // Get current scope RA
                            gotoOutputRA();
                            break;

                        case 'S':       // Output siderial time
                            /* ASCOM driver wants this from Meade/Autostar.
                             * Fake it.
                             */
                            serialTx("00:00:00#");
                            break;


                        default:
                            UDR1 = '?';
                        }
                    }
                    else if (lxPos == 3 && lxCmd[1] == 'V')
                    {
                        switch (lxCmd[2])
                        {
                        case 'D':       // Get firmware date
                            serialTx(FIRMWARE_DATE "#");
                            break;

                        case 'N':       // Get firmware revision
                            serialTx(FIRMWARE_REV "#");
                            break;

                        case 'P':       // Get product name
                            serialTx(PRODUCT_NAME "#");
                            break;

                        case 'T':       // Get firmware time
                            serialTx(FIRMWARE_TIME "#");
                            break;

                        default:
                            UDR1 = '?';
                        }
                    }
                    break;

                case 'M':       // Start guiding in specified direction
                    if (lxPos == 2)
                    {
                        // We have the right number of chars */
                        switch (lxCmd[1])
                        {
                        case 'n': upFlag = 1; downFlag = 0; decChg = 1; break;
                        case 's': upFlag = 0; downFlag = 1; decChg = 1; break;
                        case 'e': rightFlag = 1; leftFlag = 0; raChg = 1; break;
                        case 'w': rightFlag = 0; leftFlag = 1; raChg = 1; break;

                        case 'S':
                            // GOTO the specified position
                            gotoTarget();
                            break;

                        default: UDR1 = '?'; break;
                        }
                    }
                    else if (lxPos >= 4 && lxCmd[1] == 'g')
                    {
                        uint16_t     pulseTime;

                        // This is a pulseguide (timed guide correction) command
                        lxCmd[lxPos] = '\0';
                        pulseTime = atoi(lxCmd + 3);
                        
                        switch (lxCmd[2])
                        {
                        case 'n': 
                            upFlag = 1;
                            downFlag = 0;
                            decChg = 1;
                            break;
                        case 's': 
                            upFlag = 0; 
                            downFlag = 1; 
                            decChg = 1;
                            break;
                        case 'e': 
                            rightFlag = 1; 
                            leftFlag = 0; 
                            raChg = 1;
                            break;
                        case 'w': 
                            rightFlag = 0; 
                            leftFlag = 1; 
                            raChg = 1;
                            break;
                        }

                        /* Clear all movement flags if time == 0. The raChg
                         * and decChg flags will cause any movement in
                         * the specified axis to be stopped
                         */
                        if (pulseTime == 0)
                             upFlag = downFlag = leftFlag = rightFlag = 0;
                        else
                             timed = 1;

                        /* Assign RA and DEC timer values depending on what
                         * the pulseguide requested
                         */
                        if (raChg)
                        {
                            raPulseTime = pulseTime;
                        }

                        if (decChg)
                        {
                            decPulseTime = pulseTime;
                        }

                    }
                    break;

                case 'Q':       // Stop guiding in specified direction
                    if (lxPos == 1)
                    {
                        // Stop slewing
                        upFlag = downFlag = leftFlag = rightFlag = 0;
                        raChg = decChg = 1;

                        // Stop goto
                        gotoStop();
                    }
                    else if (lxPos == 2)
                    {
                        // Stop slewing is specified direction
                        switch (lxCmd[1])
                        {
                        case 'n': upFlag = 0; decChg = 1; break;
                        case 's': downFlag = 0; decChg = 1; break;
                        case 'e': rightFlag = 0; raChg = 1; break;
                        case 'w': leftFlag = 0; raChg = 1; break;
                        default: UDR1 = '?'; break;
                        }
                    } else
                        UDR1 = '?';
                    break;

                case 'R':           // Set guiding speed
                    if (lxPos == 2)
                    {
                        switch (lxCmd[1])
                        {
                        case 'G':   guideRate = SPEED_0_33_X; break;
                        case 'C':   guideRate = SPEED_1_X; break;
                        case 'M':   guideRate = SPEED_8_X; break;
                        case 'S':   guideRate = SPEED_16_X; break;
                        case '1':   break;      // Undocumented: Meade DSI
                        default: UDR1 = '?'; break;
                        }
                    }
                    break;

                case 'S':       // Set GOTO RA/DEC
                    // Null-terminate the string
                    lxCmd[lxPos] = '\0';

                    // Choose which thing to set
                    switch (lxCmd[1])
                    {
                    case 'r':
                        gotoSetRA(lxCmd + 2);
                        break;

                    case 'd':
                        gotoSetDec(lxCmd + 2);
                        break;

                    default:
                        UDR1 = '?';
                    }

                    break;

                case 'U':       // Toggle display precision
                    if (lxPos == 1)
                         gotoTogglePrecision();
                    else
                        UDR1 = '?';
                    break;

                default:
                    UDR1 = '?';
                }
            }
        }
    }

    /* Update the serial guiding rate data if it has changed */
    if (decChg)
    {
        // Set direction and speed if requested
        if (upFlag)
            rateInput.serialDecRate = guideRate;
        else if (downFlag)
            rateInput.serialDecRate = -guideRate;
        else
            rateInput.serialDecRate = SPEED_0_X;

        // If this move isn't timed, cancel the timer
        if ( ! timed)
            decPulseTime = 0;
        
        updateMountSpeed();
    }

    if (raChg)
    {
        // Set direction and speed if requested
        if (rightFlag)
            rateInput.serialRaRate = guideRate;
        else if (leftFlag)
            rateInput.serialRaRate = -guideRate;
        else
            rateInput.serialRaRate = SPEED_0_X;

        // If this move isn't timed, cancel the timer
        if ( ! timed)
            raPulseTime = 0;
        
        updateMountSpeed();
    }

}

#if 1

/* The following code is for debugging. Disable it to reduce code size in
 * production versions
 */
char    toHex[] = "0123456789abcdef";

void
print16(uint16_t num)
{
    char        out[5];

    out[0] = toHex[(num >> 12) & 0xf];
    out[1] = toHex[(num >> 8) & 0xf];
    out[2] = toHex[(num >> 4) & 0xf];
    out[3] = toHex[(num >> 0) & 0xf];
    out[4] = '\0';

    serialTx(out);
}

void
print32(uint32_t num)
{
    print16(num >> 16);
    print16(num & 0xffff);
}
#endif
