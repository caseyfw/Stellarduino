/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: goto.h,v 1.3 2004/05/23 20:57:38 dbh Exp $
 */

#ifndef _GOTO_H_
#define _GOTO_H_

#include <avr/io.h>
#include "stepper.h"

/* Define the bits with the switch that controls the DEC direction
 */
#define GOTO_SW_PORT    PORTD
#define GOTO_SW_PIN     PIND
#define GOTO_SW_DDR     DDRD

#define GOTO_SW_BIT     2
#define GOTO_LED_BIT    3


/* Prototypes for the goto functions */

void    gotoOutputRA(void);
void    gotoOutputDec(void);
void    gotoTogglePrecision(void);

void    gotoSetRA(char *pStr);
void    gotoSetDec(char *pStr);
void    gotoTarget(void);
void    gotoSync(uint8_t resp);
void    gotoStop(void);

void gotoInt(void);
void gotoInit(void);

// Save/restored controls for GOTO rate
extern uint8_t  gotoRate;               // Numeric speed
extern uint8_t  gotoSpeed;              // Speed specifier ie. SPEED_24_X
extern uint8_t  gotoDeltaSync;          // Synchronise to target of long slew

#endif /* _GOTO_H_ */

