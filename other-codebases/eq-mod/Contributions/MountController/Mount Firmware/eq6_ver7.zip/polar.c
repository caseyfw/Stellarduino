/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: polar.c,v 1.2 2004/08/29 05:33:15 dbh Exp $
 */
#include <avr/io.h>
#include <inttypes.h>

#include "polar.h"

/* The polar scope task generates a PWM output for a polar scope illumination
 * LED attached to the port/bin spedified in polar.h
 */

/* Polar scope task configuration
 */
uint8_t         polarLevel;

/* polarInit() sets the initial state of the polar scope LED task
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
polarInit(void)
{
    // Set LED output as output and off
    POLAR_PORT &= ~_BV(POLAR_BIT);
    POLAR_DDR |= _BV(POLAR_BIT);
}

/* polarInt() is called every motor step time (about 32 kHz) to update the
 * polar scope illuminator LED state
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
polarInt(void)
{
    static unsigned int         count;

    // Increment count
    if (count >= (256 * POLAR_SCALE))
        count = 0;
    else
        ++count;

    // Update the LED
    POLAR_PORT  =               (count < polarLevel)
                                ? (POLAR_PORT | _BV(POLAR_BIT))
                                : (POLAR_PORT & ~_BV(POLAR_BIT));
}
    
