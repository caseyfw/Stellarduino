/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: combine.h,v 1.7 2005/10/04 04:39:05 dbh Exp $
 */
#ifndef _COMBINE_H_
#define _COMBINE_H_

#include <inttypes.h>

/* This file gives the "public" interface for the "combining" function
 * that takes the various inputs (siderial rate, paddle buttons, serial
 * input, guider input) to derive speeds for the RA and DEC axis
 */

/* Speed definitions */
#define SPEED_0_X	0
#define SPEED_0_33_X	1
#define SPEED_0_67_X	2
#define SPEED_1_X	3
#define SPEED_1_33_X    4
#define SPEED_1_67_X    5
#define SPEED_2_X	6
#define SPEED_4_X       7
#define SPEED_8_X	8
#define SPEED_16_X	9
#define SPEED_24_X      10

#define SPEED_SPIN      SPEED_24_X
#define SPEED_SIDERIAL	SPEED_1_X

struct rateInput_s
{
	int8_t		siderialRate;

        int8_t          gotoRaRate;
        int8_t          gotoDecRate;

	int8_t		paddleRaRate;
	int8_t		paddleDecRate;

	int8_t		serialRaRate;
	int8_t		serialDecRate;

	int8_t		guideRaRate;
	int8_t		guideDecRate;
};

extern struct rateInput_s	rateInput;

struct rateOutput_s
{
	int8_t		raRate;
	int8_t		decRate;
};

extern struct rateOutput_s rateOutput;

void updateMountSpeed(void);

/* TEST: defeat tracking for testing */
extern uint8_t          noTrack;

#endif /* _COMBINE_H_ */
