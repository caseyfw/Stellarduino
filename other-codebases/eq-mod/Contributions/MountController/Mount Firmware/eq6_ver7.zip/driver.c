/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: driver.c,v 1.10 2005/10/04 04:37:34 dbh Exp $
 */

/* This file contains the code that takes the excitation values for each
 * coil (determined by the stepper module) and performs a crude PWM
 * and generates the output values for the stepper drivers.
 *
 * This module has it's own timer at a high frequency timer, so efficiency
 * is an important issue.
 */

#include <avr/io.h>
#include <avr/signal.h>
#include <inttypes.h>

#include "eq6.h"
#include "stepper.h"
#include "driver.h"
#include "polar.h"

/* Like the stepper.h module this one is heavily table-driven. Basically
 * each excitation value corresponds to 4, 8 bit lists of values are used
 * for 8 clock cycles. This gives a crude PWM system.
 *
 * The hardware is orginized such that both "ends" of a coil are in
 * adjacent bits, so each pair of 8 bits is interleaved into a single
 * 16 bit word where the bits are used two at a time.
 *
 * Note: The high side and low side tables here were different - basically if
 * a high side was driven for one coil, the low side should be driven for the
 * other.
 *
 * However the low side bits are reversed because of the bit numbers running
 * in the opposite direction for Port A (low side) vs Port C (high side), so
 * it turns out that the same table can be used for both!
 *
 * Of course the bits for the coils are composed in the opposite direction
 * too, but that happens below
 */

static uint8_t  ex_m_1[4] = {0xaa, 0xaa, 0xaa, 0xaa};

static uint8_t  ex_m_0_98[4] = {0xaa, 0xaa, 0xaa, 0x2a};
static uint8_t  ex_m_0_92[4] = {0xaa, 0x2a, 0xaa, 0x2a};
static uint8_t  ex_m_0_83[4] = {0x2a, 0x2a, 0x2a, 0xaa};
static uint8_t  ex_m_0_7[4] = {0x2a, 0x2a, 0x2a, 0x2a};
static uint8_t  ex_m_0_56[4] = {0x22, 0x2a, 0x22, 0x2a};
static uint8_t  ex_m_0_4[4] = {0x08, 0x22, 0x82, 0x28};
static uint8_t  ex_m_0_2[4] = {0x00, 0x80, 0x20, 0x08};

static uint8_t  ex_0[4] = {0x00, 0x00, 0x00, 0x00};

static uint8_t  ex_p_0_2[4] = {0x00, 0x40, 0x10, 0x04};
static uint8_t  ex_p_0_4[4] = {0x04, 0x11, 0x41, 0x14};
static uint8_t  ex_p_0_56[4] = {0x11, 0x15, 0x11, 0x15};
static uint8_t  ex_p_0_7[4] = {0x15, 0x15, 0x15, 0x15};
static uint8_t  ex_p_0_83[4] = {0x15, 0x15, 0x15, 0x55};
static uint8_t  ex_p_0_92[4] = {0x55, 0x15, 0x55, 0x15};
static uint8_t  ex_p_0_98[4] = {0x55, 0x55, 0x55, 0x15};

static uint8_t  ex_p_1[4] = {0x55, 0x55, 0x55, 0x55};

uint8_t* driveTbl[] =
{
    [EX_M_1] = ex_m_1,
    [EX_M_0_98] = ex_m_0_98,
    [EX_M_0_92] = ex_m_0_92,
    [EX_M_0_83] = ex_m_0_83,
    [EX_M_0_56] = ex_m_0_56,
    [EX_M_0_7] = ex_m_0_7,
    [EX_M_0_4] = ex_m_0_4,
    [EX_M_0_2] = ex_m_0_2,
    [EX_0] = ex_0,
    [EX_P_0_2] = ex_p_0_2,
    [EX_P_0_4] = ex_p_0_4,
    [EX_P_0_56] = ex_p_0_56,
    [EX_P_0_7] = ex_p_0_7,
    [EX_P_0_83] = ex_p_0_83,
    [EX_P_0_92] = ex_p_0_92,
    [EX_P_0_98] = ex_p_0_98,
    [EX_P_1] = ex_p_1
};

#define PWM_RATE        48000           /* PWM update speed */
#define PWM_STEPS       16              /* Steps per PWM cycle */

#define RELAY_CHANGE    10              /* 10 ms period to wait while
                                         * changing the relay state. If odd
                                         * then the relay changes @ 2/3 of the
                                         * time
                                         */

/* driverInit() initializes the port used by the stepper motors and the timer
 * used to update the stepper driver state
 *
 * Passed:
 *      Nothing
 *
 * Returns:
 *      Nothing
 *
 */
void
driverInit(void)
{
    /* Set up port A and C as outputs and set them to a safe default state
     * i.e. no outputs driven
     */
    PORTA = 0xff;               // Disable high-side drivers
    DDRA = 0xff;                // Set as outputs

    PORTC = 0x00;               // Disable low-side drivers
    DDRC = 0xff;                // Set as outputs

    /* Setup the "magic" relay bit as an output */

    MAGIC_PORT &= ~MAGIC_BITS;
    MAGIC_DDR |= MAGIC_BITS;

    /* Setup timer 0 to generate interrupts for PWM */
    OCR0 = (CLK_RATE / PWM_RATE / 8);
    TCCR0 = _BV(WGM01) | _BV(CS01);     // Divied by 8, CTC mode

    /* Enable interrupt generation from timer 0 */
    TIMSK |= _BV(OCIE0);
DDRB |= 0x80;
}

/* driverInt() is called whenever a timer 0 overflow interrupt occurs
 *
 * Passed:
 *      Nothing
 *
 * Returns:
 *      Nothing
 */
SIGNAL(SIG_OUTPUT_COMPARE0)
{
    static uint8_t      raCoil1States;
    static uint8_t      raCoil2States;
    
    static uint8_t      decCoil1States;
    static uint8_t      decCoil2States;

    static uint8_t      ctr = PWM_STEPS - 1;
    static uint8_t      curRelay = 0x55;        // Force non-match at startup

    uint8_t             highSidePort;
    uint8_t             lowSidePort;

PORTB |= 0x80;

// PORTA = ~excitation.ra;
// PORTC = ~excitation.dec;

#if RELAY_CHANGE
    /* It seems that changing the relay state while the RA coils are
     * activated induces lots of noise - enough the reset the CPU!
     *
     * The following code detects changes of relay state and deactivates
     * the coils before and after changing the relay state
     */
    if (raExcitation.counter > 0)
    {
        /* A relay change is in progress. See it it's time to update the
         * relay state
         */
        if (raExcitation.counter == (RELAY_CHANGE / 2))
        {
            /* Update relay state not that the coils have been idle for
             * half of the relay change time
             */
            if (raExcitation.useRelay)
                MAGIC_PORT &= ~MAGIC_BITS;
            else
                MAGIC_PORT |= MAGIC_BITS;

            curRelay = raExcitation.useRelay;
        }

        /* In any case force the activation to off */
        raCoil1States = driveTbl[EX_0][0];
        raCoil2States = driveTbl[EX_0][0];
        decCoil1States = driveTbl[EX_0][0];
        decCoil2States = driveTbl[EX_0][0];
    }
    else if (raExcitation.useRelay != curRelay)
    {
        /* Relay state has changed - initiate the relay state change */
        raExcitation.counter = RELAY_CHANGE;
        raExcitation.halt = 1;          // Stop stepping
    }
    else
#endif  /* RELAY_CHANGE */
    {
        /* Normal operation */
        raExcitation.halt = 0;          // Allow stepping

        /* Wrap counter around if necessary */
        if (++ctr == PWM_STEPS)
             ctr = 0;

        /* Update the coil values every four passes */
        if ((ctr & 0x3) == 0)
        {
            uint8_t     idx = ctr >> 2;

            /* Update states */
            raCoil1States = driveTbl[raExcitation.c1Ex][idx];
            raCoil2States = driveTbl[raExcitation.c2Ex][idx];
            decCoil1States = driveTbl[decExcitation.c1Ex][idx];
            decCoil2States = driveTbl[decExcitation.c2Ex][idx];

#if ! RELAY_CHANGE
            /* Update magic relay state */
            if (raExcitation.useRelay)
                MAGIC_PORT &= ~MAGIC_BITS;
            else
                MAGIC_PORT |= MAGIC_BITS;
#endif /* RELAY_CHANGE */
        }
    }

    /* Build the high_side driver output value */
    highSidePort = decCoil2States & 0x3;
    highSidePort <<= 2;

    highSidePort |= decCoil1States & 0x3;
    highSidePort <<= 2;

    highSidePort |= raCoil2States & 0x3;
    highSidePort <<= 2;

    highSidePort |= raCoil1States & 0x3;

    /* Build the low-side driver states. Note that, due to the
     * reverse pin ordering for Port A vs Port C that these are built in
     * the opposite direction and bit reversed
     */
    lowSidePort = raCoil1States & 0x3;
    lowSidePort <<= 2;
    raCoil1States >>= 2;

    lowSidePort |= raCoil2States & 0x3;
    lowSidePort <<= 2;
    raCoil2States >>= 2;

    lowSidePort |= decCoil1States & 0x3;
    lowSidePort <<= 2;
    decCoil1States >>= 2;

    lowSidePort |= decCoil2States & 0x3;
    decCoil2States >>= 2;

    /* Potential safety check: rev (PortA) & PortC == 0 */

    /* Write the values to the output ports */
    PORTC = highSidePort;
    PORTA = ~lowSidePort;

    /* This is a bit of a kludge, but it is a fast interrupt that will
     * be great for the polar scope LED PWM
     */
    polarInt();

PORTB &= ~0x80;
}
