/* 
 * Copyright (C) 2005 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: heater.c,v 1.1 2006/02/26 06:34:40 dbh Exp $
 */

#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>

#include "consts.h"
#include "heater.h"

/* The current heater state */
static uint8_t          heaterLevel;

/* heaterInit() initializes the state of the heater
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
heaterInit(void)
{
    heaterLevel = 0;

    HEAT_DDR |= HEAT_VAL;       // Set as output
    HEAT_PORT &= ~HEAT_VAL;     // Turn off
}

/* headerSet() sets the drive level for the heater
 *
 * Passed
 *      level   The drive level (0 .. HEATER_RANGE)
 *
 * Returns
 *      nothing
 */
void
heaterSet(uint8_t level)
{
    heaterLevel = (level > HEATER_RANGE) ? HEATER_RANGE : level;
}

/* heaterGet reads the drive level for the heater
 *
 * Passed
 *      nothing
 *
 * Returns
 *      The current drive level (0 .. HEATER_RANGE)
 */
uint8_t
heaterGet(void)
{
    return heaterLevel;
}

/* heaterPoll() is called periodically the update the output of the heater
 * bit so that it is on the required proprtion of the total time
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
heaterPoll(void)
{
    static uint8_t      heaterCtr;

    // Set the output bit
    if (heaterCtr < heaterLevel)
         HEAT_PORT |= HEAT_VAL;
    else
         HEAT_PORT &= ~HEAT_VAL;

    // Update the heater counter
    if (++heaterCtr == HEATER_RANGE)
         heaterCtr = 0;
}
