/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: sr.c,v 1.5 2005/09/25 08:54:23 dbh Exp $
 */

#include <avr/eeprom.h>
#include "sr.h"

/* Provide the global SR data instance
 */
persist_t       gData;

/* srRead() reads the persistent data from the EEPROM. If the data isn't
 * valid then return defaults
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
srRead(void)
{
    /* Read the EEPROM data */
    eeprom_read_block(&gData, (const uint8_t *)0, sizeof(gData));

    /* See if the EEPROM has been initialized. If not the set up the global
     * data and write it back
     */
    if (gData.uninit != 0x55)
    {
        gData.uninit = 0x55;        // Mark structure as initialized

        gData.ustepPerStep = 10;    // 10 fullsteps per step
        gData.msPerUStep = 3;       // 3 ms per fullstep
        gData.duty = 50;            // stepper duty cycle when holding

        gData.backlash = 5;         // 5 steps of backlash
        gData.endDir = 1;           // End travel in "out" direction

        gData.position = 0;         // Current position
        gData.phase = 0;            // Current stepper phase

        // Allowed travel in microsteps
        gData.travel = 2590 * gData.ustepPerStep;

        /* Write the newly initialized data back */
        srWrite();
    }
}

/* srWrite() writes the current persistent data back to EEPROM
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 *
 * Note
 *      Values are only written if different
 */
void
srWrite(void)
{
    uint8_t     addr;
    uint8_t     *ptr;

    /* Loop over all the bytes of the structure in EEPROM */
    for (       addr = 0, ptr = (uint8_t *)&gData ;
                addr < sizeof(gData) ;
                ++addr, ++ptr)
    {
        /* If the byte is different then write the new value */
        if (eeprom_read_byte((const uint8_t *)addr) != *ptr)
            eeprom_write_byte((uint8_t *)addr, *ptr);
    }
}
