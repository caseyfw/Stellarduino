/* 
 * Copyright (C) 2005 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: main.c,v 1.6 2006/02/26 06:34:40 dbh Exp $
 */

#include <inttypes.h>
#include <avr/interrupt.h>
#include <avr/signal.h>
#include <avr/io.h>
#include <avr/eeprom.h>

#include "consts.h"
#include "stepper.h"
#include "motion.h"
#include "button.h"
#include "serial.h"
#include "sr.h"
#include "top.h"
#include "temp.h"
#include "heater.h"

/* main() is called by AVRGCC after the system has been initialized.
 *
 * Timer1 is used to construct a 1 ms polling loop
 *
 * Passed
 *      nothing
 *
 * Returns
 *      never
 */
int
main(void)
{
    uint16_t            srTime = 0;     // Timer for state save

    /* Initialize all the modules */
    srRead();
    motionInit();
    serialInit();
    buttonInit();
    stepperInit();
    tempInit();
    heaterInit();

    /* Initialize timer1 */
    TCCR1A = 0;                         // Set CTC mode
    TCCR1B = _BV(CS10) | _BV(WGM12);    // Divide by 1
    OCR1A = CLK_RATE / TMR_FREQ - 1;    // Set timeout
    TCNT1 = 0;                          // Reset counter
    
    /* Enable interrupts */
    sei();

    /* Start the main loop.
     */
    for (;;)
    {
        /* Wait for the timer to expire. Do stuff that needs to be
         * run continuously
         */
        if (TIFR & _BV(OCF1A))
        {
            // Cancel timer
            TIFR = _BV(OCF1A);

            // Do the top level state machine
            topPoll();

            // Update the SR timer and save if timed out
            if (( ! motionCurrent()) && ++srTime == SR_WRITEBACK)
            {
                srTime = 0;
                srWrite();
            }
        }
    }

    /* NOTREACHED */
    return 0;
}
