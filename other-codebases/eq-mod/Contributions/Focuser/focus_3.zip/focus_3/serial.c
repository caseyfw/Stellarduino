/* 
 * Copyright (C) 2005 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: serial.c,v 1.3 2005/05/28 20:24:45 dbh Exp $
 */

#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>
#include <stdlib.h>     // utoa()
#include <avr/signal.h>

#include "consts.h"
#include "serial.h"
#include "motion.h"
#include "button.h"

static message_t        rxMsg;
static uint8_t          rxChar;
static uint16_t         rxTimer;

static message_t        txMsg;

/* serialTxInt() is called whenever a character needs to be sent.
 *
 * Passed:
 *      Nothing
 *
 * Returns:
 *      Nothing
 *
 * Notes:
 *      The UART generates a interrupt whenever it wants another character.
 *      If there are no characters to send we just disable the interrupt
 *
 *      Note that normal "-" and "+" position change characters are sent
 *      polled using serialTxChar()
 */
void
serialTxInt(void)
{
    /* We may be poking this while we're already running, so make sure we're
     * really idle - else use return, we'll get another interrupt when it's
     * done
     */
    if ( ! (UCSRA & _BV(UDRE)))
        return;

    switch (txMsg.pos)
    {
    case -2:                    // Start sending this message
        UDR = 'F';
        txMsg.pos = -1;
        break;

    case -1:                    // Send the command character
        UDR = txMsg.cmd;
        txMsg.pos = 0;
        break;

    case 0 ... CDLEN - 1:       // Send the command data
        UDR = txMsg.data[txMsg.pos];
        ++txMsg.pos;
        break;

    case CDLEN:                 // Send the checksum character & mark as idle
        UDR = txMsg.csum;
        txMsg.pos = CDLEN + 1;  // Mark as empty
        break;

    case CDLEN + 1:             // No message to send yet
        // UCSRB &= ~_BV(TXCIE);
        break;
    }
}

SIGNAL(SIG_UART_TRANS)
{
    serialTxInt();
}


/* serialRxInt() is called whenever a character is received on USART.
 *
 * The characters are assembled into a message and made available to the
 * software outside the ISR for further processing.
 *
 * Passed
 *      Nothing
 *
 * Returns
 *      Nothing
 */
SIGNAL(SIG_UART_RECV)
{
    char        ch;

    /* Get the character from the port. This will dismiss the interrupt
     */
    ch = UDR;
    rxChar = 1;

    /* Decide what to do with the character. It depends on what has been
     * received previously
     */
    switch (rxMsg.pos)
    {
    case -2:                    // Start of message
        if (ch == 'F')
        {
            rxTimer = 0;
            rxMsg.pos = 0;      // next char is first of cmd/data msg
            rxMsg.csum = 'F';
            rxMsg.pos = -1;
        }
        break;

    case -1:                     // command character
        rxMsg.cmd = ch;
        rxMsg.csum += ch;
        rxMsg.pos = 0;
        break;

    case 0 ... CDLEN - 1:        // Get the cmd & associated data
        rxMsg.data[rxMsg.pos] = ch;
        ++rxMsg.pos;
        rxMsg.csum += ch;
        break;

    case CDLEN:                 // We have the checksum - check it!
        if (ch == rxMsg.csum)
        {
            // Checksum OK - move on
            ++rxMsg.pos;
            rxChar = 0;
        }
        else
        {
            // Checksum bad - throw it all away
            rxMsg.pos = -1;
        }
        break;

    case CDLEN + 1:             // Nobody has taken the message yet.
        break;
    }
}

/* serialInit() initializes the serial port used for the 
 * serial guider input.
 *
 * Passed:
 *         Nothing
 *
 * Returns:
 *         Nothing.
 */
void
serialInit(void)
{
    uint16_t    brate;

    /* Initialize the RX and TX message buffers
     */
    serialRxDone(&rxMsg);
    txMsg.pos = CDLEN + 1;

    // Set serial rate
    brate = (CLK_RATE / GUIDE_BAUD / 16 - 1) & 0xff;

    UBRRH = brate >> 8;
    UBRRL = brate & 0xff;

    /* Setup registers
     * 8 bits, no parity, RX enable, TX enable. Only the Rx interrupts are
     * enabled at this point.
     */
    UCSRC = _BV(URSEL) | _BV(UCSZ1) | _BV(UCSZ0);
    UCSRB = _BV(RXEN) | _BV(TXEN) | _BV(RXCIE);
}

/* serialTxChar() sends a single character to the serial port.
 *
 * Passed:
 *      ch      The character to send
 *
 * Returns
 *      nothing
 *
 * Note:
 *      This should only be called with interrupts enabled
 */
void
serialTxChar(char ch)
{
    /* Wait for the UART to be ready for another character */
    while ( ! (UCSRA & _BV(UDRE)))
        ;

    UDR = ch;
}

/* serialTxMsg() prepares a message for transfer and sends it. The call
 * will stall until a transmit buffer is ready
 *
 * Passed
 *      cmd     The command character
 *      data    CDLEN - 1 chars of data
 *
 * Returns:
 *      nothing
 */
void
serialTxMsg(char cmd, char data[CDLEN - 1])
{
    uint8_t     idx;
    char        csum;

    /* See if the next buffer is free. If not then wait for it.
     */
    while (txMsg.pos != (CDLEN + 1))
        ;

    /* Copy the command and data into the transmit message. Calculate the
     * checksum while copying
     */
    txMsg.cmd = cmd;
    for (idx = 0, csum = 'F' + cmd ; idx < CDLEN ; ++idx)
    {
        txMsg.data[idx] = data[idx];
        csum += data[idx];
    }
    
    txMsg.csum = csum;

    /* Mark the buffer as ready to send.
     */
    txMsg.pos = -2;

    /* Enable interrupts and kick off the transfer
     */
    cli();
    UCSRB |= _BV(TXCIE);
    serialTxInt();
    sei();
}

/* serialPoll() is called every millisecond to do whatever serial processing
 * needs to be done
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
serialPoll(void)
{

    /* Check for a serial timeout. If the timeout occurs then cancel any
     * command in process
     */
    if (rxMsg.pos >= 0 && ++rxTimer == RX_TIMEOUT)
        rxMsg.pos = -1;
}

/* serialWasChar() tells the caller whether there was a serial character
 * received that did not complete a serial command since the last time this
 * was called
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 *
 * Notes:
 *      The "did not complete" clause is intended to prevent a spurious
 *      indication on commnad complete. This is actually implemented in the
 *      receive state machine
 */
uint8_t
serialWasChar(void)
{
    if (rxChar)
    {
        rxChar = 0;
        return 1;
    }
    else
        return 0;
}

/* serialRxMsg() fetches a pointer to a received message, if any
 *
 * Passed
 *      nothing
 *
 * Returns
 *      A pointer to the received message, or 0 if none has been received
 */
message_t *
serialRxMsg(void)
{
    return (rxMsg.pos >= (CDLEN + 1)) ? &rxMsg : 0;
}

/* serialRxDone() marks the message processing as complete
 *
 * Passed
 *      pMsg    Pointer to the message
 *
 * Returns
 *      nothing
 */
void
serialRxDone(message_t *pMsg)
{
    pMsg->pos = -2;
}

#if 0
/* The following code is for debugging. Disable it to reduce code size in
 * production versions
 */
char    toHex[] = "0123456789abcdef";

void
print8(uint8_t num)
{
    char        out[3];

    out[0] = toHex[(num >> 4) & 0xf];
    out[1] = toHex[(num >> 0) & 0xf];
    out[2] = '\0';

    serialTx(out);
}

void
print16(uint16_t num)
{
    print8(num >> 8);
    print8(num & 0xff);
}

void
print32(uint32_t num)
{
    print16(num >> 16);
    print16(num & 0xffffUL);
}
#endif
