/* 
 * Copyright (C) 2005 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: top.c,v 1.7 2006/02/26 06:34:40 dbh Exp $
 */

#include "top.h"

#include "button.h"
#include "serial.h"
#include "motion.h"
#include "sr.h"
#include "temp.h"
#include "consts.h"
#include "heater.h"

/* topGetInt() gets the base-10 integer value of the specified
 * substring
 *
 * Passed
 *      pCh     Pointer to first character
 *      len     Number of characters
 *
 * Returns:
 *      The number
 */
static uint16_t
topGetInt(char *pCh, uint8_t len)
{
    uint16_t    accum;

    for (accum = 0; len != 0 ; --len)
    {
        accum = (accum * 10) + (*pCh++ - '0');
    }

    return accum;
}

/* topSetInt() converts a number into a string (base 10) and writes
 * it into a fixed length string
 *
 * Passed
 *      val     The value to write
 *      pStr    Where to write the data
 *      len     The number of characters to use
 *
 * Returns
 *      nothing
 */
static void
topSetInt(uint16_t val, char *pStr, uint8_t len)
{
    /* Write the string. Note that this needs to be done from
     * right to left to get the correct result
     */
    for (; len != 0 ; --len)
    {
        pStr[len - 1] = (val % 10) + '0';
        val = val / 10;
    }
}

/* topPoll() is called every millisecond to run the top-level state machine
 * associated with the focuser
 *
 * This takes inputs from the serial port, push buttons and motor control
 * and sends the relevent motion commnads and serial port responses
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
topPoll(void)
{
    /* State variables */
    static void         *pState = &&idle;       // Current state ptr

    static uint16_t     keyTime;                // Button debounce/rept
   
    static uint8_t      sButton;                // Current buttons pressed
    static uint8_t      sCmd;                   // Current serial cmd

    /* Working variables */
    uint8_t             mResult;                // Motion poll result
    uint16_t            num;                    // Number from cmd
    
    uint8_t             tmpByte;                // Temporary
    int                 idx;                    // Loop index

    char                str[CDLEN + 1];         // Buffer to build msg data
    message_t           *pMsg;                  // Pointer to received msg
    int32_t             ustepPos;               // Absolute tgt pos in usteps
 
    /* Do the serial port and heater polling */
    serialPoll();
    heaterPoll();

    /* Do the motion polling */
    mResult = motionPoll();

    /* If a message has been received then go and process it */
    pMsg = serialRxMsg();
    if (pMsg)
        goto serial_rx;

    // Else jump to the current state
    goto *pState;

idle:
    /* Nothing is happening at the moment. Start looking for things
     * to do. In this case, wait for a key press
     */
    sButton = buttonRead();
    if (sButton != 0)
    {
        keyTime = 0;
        pState = &&wait_debounce;
    }

    return;

wait_debounce:
    /* Button was pressed. If the button state has changed then
     * drop back to the idle state, else wait for the end of the debounce
     * time and step
     */
    if (sButton != buttonRead())
         pState = &&idle;
    else if (sButton == (BUT_LEFT | BUT_RIGHT))
    {
        // If both buttons are pressed set the current position to zero
        gData.position = 0;
        pState = &&wait_no_key;
        goto send_pos;
    }
    else if (++keyTime >= T_DEBOUNCE)
    {
        /* End of debounce reached. Perform a single "step" in
         * the direction specified by the button
         */
        if (sButton & BUT_LEFT)
            motionGoto(-gData.ustepPerStep, 0, 1);
        else
            motionGoto(gData.ustepPerStep, 0, 1);

        pState = &&wait_repeat;
    }
    return;

wait_no_key:
    /* Wait for all keys to be released and return to the idle state
     */
    if (buttonRead() == 0)
         pState = &&idle;
    return;

wait_repeat:
    /* Button was pressed and we've done the step, but we haven't started
     * repeating yet
     */
    if (sButton != buttonRead())
    {
         pState = &&idle;
         goto send_pos;
    }
    else if (++keyTime >= T_REPT)
    {
        /* End of repeat time reached. Start slewing in the direction 
         * specified by the button
         */
        if (sButton & BUT_LEFT)
            motionSlew(-1);
        else
            motionSlew(1);

        pState = &&repeating;
    }
    return;

repeating:
    /* Button is pressed and we're repeating. Wait for the buttons to be
     * released and then return to the idle state.
     * 
     * Keep checking the serial port for commands
     */
    if (sButton != buttonRead())
    {
        // Stop the stepping
        motionStop();
        pState = &&wait_stop;
    }
    return;

wait_stop:
    /* We were stepping and/or slewing. If it has stopped then return to
     * the idle state
     */
    if ( mResult & M_DONE)
    {
        pState = &&idle;
        goto send_pos;
    }
    return;

serial_rx:
    /* There is a message waiting. See what it wants :-) Note that some
     * messages can be processed outside the idle state, but any
     * message that requires motion can't be processed unless we're in
     * the idle state.
     *
     * Note that (unlike the rest of the labels) this one doesn't represent a
     * state
     */
    sCmd = pMsg->cmd;
    
    switch (sCmd)
    {
    case 'V':           // Return version number
        serialTxMsg('V', "000003");
        break;          

    case 'B':           // Set or get the backlash info
        num = topGetInt(pMsg->data + 1, CDLEN - 1);
        if (num != 0)
        {
            // Set the backlash info
            if (pMsg->data[0] == '2')
                gData.endDir = -1;
            else if (pMsg->data[0] == '3')
                gData.endDir = 1;

            gData.backlash = num;
        }

        // Send the current / new settings
        if (gData.endDir == -1)
             str[0] = '2';
        else if (gData.endDir == 1)
             str[0] = '3';
        else
             str[0] = '1';
        
        topSetInt(gData.backlash, str + 1, CDLEN - 1);

        serialTxMsg('B', str);
        break;

    case 'C':           // Get or Set configuration
        /* If the first 5 characters has ASCII value of zero then
         * don't set anything
         */
        if (            (pMsg->data[0] != '0')
                        || (pMsg->data[1] != '0')
                        || (pMsg->data[2] != '0')
                        || (pMsg->data[3] != '0')
                        || (pMsg->data[4] != '0'))
        {
            // Set the configuration parameters
            gData.duty = pMsg->data[0];
            gData.msPerUStep = pMsg->data[1];
            gData.ustepPerStep = pMsg->data[2];
            srWrite();
        }

        /* Return the current / updated configuration */
        str[0] = gData.duty;
        str[1] = gData.msPerUStep;
        str[2] = gData.ustepPerStep;
        str[3] = '*';
        str[4] = '*';
        str[5] = '*';
        serialTxMsg('C', str);

        /* Reinit motion state as the microstep/step relationship may have
         * changed
         */
        motionInit();

        break;

    case 'T':           // Return the current temprature
        /* Read the temperature (1/4 deg C) and return the value 
         * in the expected form (deg K * 2)
         */
        topSetInt((2 * 273) + (tempRead() / 2), str, CDLEN);
        serialTxMsg('T', str);
        break;

    case 'P':           // Get / Set power controls
        /* The power controls are used as a set of four binary bits
         * to set the heater output
         */

        // Get the current level
        tmpByte = heaterGet();

        // Setup str
        str[0] = '0';
        str[1] = '0';

        // Process the input string. 
        for (idx = 0; idx < 4 ; ++idx)
        {
            switch (pMsg->data[2 + idx])
            {
            case '1':           // Bit off
                str[2 + idx] = '1';
                tmpByte &= ~(1 << (3 - idx));
                break;

            case '2':           // Bit on
                str[2 + idx] = '2';
                tmpByte |= (1 << (3 - idx));
                break;

            default:         // Fetch current
                str[2 + idx] = (tmpByte & (1 << (3 - idx))) ? '2' : '1';
                break;
            }
        }

        heaterSet(tmpByte);
        serialTxMsg('P', str);
        break;

    case 'L':           // Get / Set maximum travel
        /* If the specified maximum is zero then don't set it
         */
        num = topGetInt(pMsg->data + 1, CDLEN - 1);
        if (num != 0)
        {
            gData.travel = (uint32_t)num * gData.ustepPerStep;
            srWrite();
        }
        /* Return the current/new value */
        topSetInt(gData.travel / gData.ustepPerStep, str, CDLEN);
        serialTxMsg('L', str);
        break;

    case 'S':           // Get / Set current position
        /* If the specified maximum is zero then don't set it
         */
        num = topGetInt(pMsg->data + 1, CDLEN - 1);
        if (num != 0)
        {
            gData.position = (int32_t)(num - 1) * gData.ustepPerStep;
        }

        /* Return the current/new value */
send_pos:
        topSetInt((gData.position / gData.ustepPerStep) + 1, str, CDLEN);
        serialTxMsg('D', str);
        break;

    case 'G':           // GOTO position
        /* Parse out the target position. If it's zero then just return the
         * current position. Likewise do this is if we're not in the current
         * state
         */
        num = topGetInt(pMsg->data + 1, CDLEN - 1);
        if (num == 0 || pState != &&idle)
        {
            // We're not going anywhere - output the current position
            goto send_pos;
        }
        else
        {
            ustepPos = (int32_t)(num - 1) * gData.ustepPerStep;
move_backlash:
            /* We're going somewhere! Apply the backlash to the specified
             * position and initiate the GOTO operation
             */
            if ((ustepPos > gData.position) && (gData.endDir < 0))
                 motionGoto (        ustepPos
                                     - gData.position
                                     + (gData.backlash * gData.ustepPerStep),
                                -(gData.backlash * gData.ustepPerStep),
                                0);
            else if ((ustepPos < gData.position) && (gData.endDir > 0))
                 motionGoto (       ustepPos
                                    - gData.position
                                    - (gData.backlash * gData.ustepPerStep) ,
                                gData.backlash * gData.ustepPerStep,
                                0);
            else
                 motionGoto (ustepPos - gData.position, 0, 0);

            /* Drop into the monitoring state and wait for the motion to
             * complete [or be interrupted] */
            pState = &&wait_end_move;
        }
        break;

    case 'O':           // Move outward
        ustepPos =  gData.position
                    + (         topGetInt(pMsg->data + 1, CDLEN - 1)
                                * gData.ustepPerStep);
        goto move_backlash;

    case 'I':           // Move inward 
        ustepPos =  gData.position
                    - (         topGetInt(pMsg->data + 1, CDLEN - 1)
                                * gData.ustepPerStep);
        goto move_backlash;
    }

    // Dismiss the command
    serialRxDone(pMsg);

    // Jump to the next state if we didn't initate motion
    if (pState != &&wait_end_move)
        goto *pState;
    else
        return;

wait_end_move:
    /* We're moving. Key for keys, received characters or just the simple end
     * of movement
     */
    if (serialWasChar() || buttonRead() != 0)
        motionStop();

    /* Update position information
     */
    if (mResult & M_DONE)
    {
        /* Output the current position to signify the end of command */
        topSetInt((gData.position / gData.ustepPerStep) + 1, str, CDLEN);
        serialTxMsg('D', str);

        /* Return to the idle state */
        pState = &&idle;
    }    
    else if (mResult & M_IN)
         serialTxChar('-');
    else if (mResult & M_OUT)
         serialTxChar('+');

    return;
}
