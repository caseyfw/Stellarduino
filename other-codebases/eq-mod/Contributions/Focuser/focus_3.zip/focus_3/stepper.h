/* 
 * Copyright (C) 2005 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: stepper.h,v 1.5 2005/09/25 08:54:23 dbh Exp $
 */

#ifndef __STEPPER_H__
#define __STEPPER_H__

#include <inttypes.h>
#include <avr/io.h>

/* Define the port and bits used for the stepper motor */

#define STEP_DDR        DDRC
#define STEP_PORT       PORTC
#define STEP_A          _BV(PC1)
#define STEP_B          _BV(PC2)
#define STEP_C          _BV(PC3)
#define STEP_D          _BV(PC4)

/* Functions that control stepper motion */
void stepperInit(void);
void stepperPoll(void);
void stepperMove(int8_t dir);
void stepperShutdown(void);

#endif /* __STEPPER_H__ */



