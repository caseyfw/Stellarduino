/* 
 * Copyright (C) 2005 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: stepper.c,v 1.5 2005/09/25 08:54:23 dbh Exp $
 */

#include <inttypes.h>
#include "consts.h"
#include "stepper.h"
#include "sr.h"

static uint8_t  steps[] =
{
    /* Full step table for bipolar stepper motor. STEP_A and STEP_B
     * drive one coil, STEP_C and STEP_D drive the other
     */
    STEP_A | STEP_C,
    STEP_A | STEP_D,
    STEP_B | STEP_D,
    STEP_B | STEP_C
};

#define STEP_MASK       (STEP_A | STEP_B | STEP_C | STEP_D)

static uint16_t         timer;
static uint16_t         onTime;

/* stepperUpdate() updates the outputs to reflect the current stepper phase
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
static void
stepperUpdate(void)
{
    STEP_PORT = (STEP_PORT & ~STEP_MASK) | steps[gData.phase & (sizeof(steps) - 1)];
}

/* stepperInit() initializes the stepper code
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
stepperInit(void)
{
    /* Initialize the stepper port */
    STEP_DDR |= STEP_MASK;

    /* Set to the intial state (no coils energized) */
    stepperShutdown();
    
    /* Energize to the current phase */
    stepperUpdate();
}

/* stepperShutdown() turns off all the motor coils
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
stepperShutdown(void)
{
    STEP_PORT &= ~STEP_MASK;
}

/* stepperPoll() is called every timer expiry to support the
 * shutdown feature
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
stepperPoll(void)
{
    /* Update the timer and shut down if necessary
     */
    if (++timer >= POWERDOWN_TICKS)
    {
        timer = POWERDOWN_TICKS;
        stepperShutdown();
    }
    else if (timer > gData.msPerUStep)
    {
        /* We're holding the coil. Drive it at the specified duty cycle
         */
        if (            ((uint32_t)onTime * 100UL)
                        < ((uint32_t)gData.duty * (uint32_t)timer))
        {
            ++onTime;
            stepperUpdate();
        }
        else
            stepperShutdown();
    }
}

/* stepperMove() does a step in the direction specified by the sign of the
 * direction passed.
 *
 * Passed
 *      dir     The direction to move in (1 = pos, -1 = neg, 0 = update)
 *
 *
 * Returns
 *      nothing
 */
void
stepperMove(int8_t dir)
{
    // Update phase
    gData.phase += dir;

    // Update the state
    stepperUpdate();

    // Clear the powerdown timer
    timer = 0;
    onTime = 0;
}
