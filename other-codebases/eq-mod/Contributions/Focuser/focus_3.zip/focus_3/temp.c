/* 
 * Copyright (C) 2005 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: temp.c,v 1.3 2005/10/30 09:30:45 dbh Exp $
 */

#include <inttypes.h>
#include <avr/io.h>
#include <avr/interrupt.h>

#include "consts.h"
#include "temp.h"

/* delayUS() delays for (approximately) the specified time.
 *
 * Passed:
 *      delay   The number of microseconds to delay
 *
 * Returns:
 *      Nothing
 *
 * Notes:
 *      The constants in this function are tuned for a 8MHz clock
 *      and the ATMEGA8 execution time
 */
static void
delayUS(volatile uint16_t delay)
{
    volatile uint8_t    qloop;
    uint8_t             sloop;
    volatile uint8_t    var;

    /* There is a minimum delay time (when the call overheads are
     * considered). If we want to delay for less than that time then
     * just return
     */
#define MIN_TIME        7
    if (delay < MIN_TIME)
        return;
    else
        delay -= MIN_TIME;

    /* Decompose the delay into quick loops and slow loops */
    qloop = delay % 256;
    sloop = delay >> 8;

    /* Do the slow loop. These take 256 us each
     */
    for (var = 0 ; var < sloop ; ++var)
    {
        volatile uint8_t        ctr;
#define BLOOP   168
        for (ctr = 0 ; ctr < BLOOP ; ++ctr)
        {
            asm("nop");
        }
    }

    /* Do the quick loop. This is the trailing part
     */
    while (qloop > 0)
        --qloop;
}

/* dsInit() initializes the resets and initializes the DS1822 device.
 *
 * Passed:
 *         Nothing
 *
 * Returns:
 *         0    Device not present
 *         1    Device present
 *
 * Note:
 *      This function ends with the DQ line in a tristate condition. An
 *      external pullup should ensure that it is high
 */
uint8_t
dsInit(void)
{
    // Force DQ pin to pulled-up input.
    TEMP_PORT &= ~TEMP_DQ;              // Disable pullup
    TEMP_DDR &= ~TEMP_DQ;               // Set DQ as input

    /* Reset and detect the presence of DS1822. The process is, basically, to
     * pull the DQ line low for >480us, then going back to the input mode.
     *
     * If the device is present it will start pulling the DQ line low
     * after 15 - 60 us and continue for 60 - 240 us
     *
     * So we check it after 70us. If it's low then the device is present
     * and we wait for the lint to return to the high state.
     */
    TEMP_DDR |= TEMP_DQ;               // Set DQ as output. TEMP_PORT is 0

    delayUS(480);

    TEMP_DDR &= ~TEMP_DQ;              // Set DQ as input, tristate

    delayUS(70);

    if (TEMP_PIN & TEMP_DQ)            // Device present?
    {
        // Not present. Oh well....
        return 0;
    }
    else
    {
        // Wait for the reset high time (tRSTH)
        delayUS(410);
        return 1;
    }
}

/* dsReadByte() reads a byte from the DS1822
 *
 * Passed:
 *     Nothing
 *
 * Returns:
 *     The byte read from the device.
 *
 * Notes:
 *     Assumes the port has the PORT bit set to zero and is
 *     an input (ie the pin is input and tristated)
 */
uint8_t
dsReadByte(void)
{
    uint8_t     mask;
    uint8_t     bit;
    uint8_t     val;

    for (       mask = 1, bit = 0, val = 0;
                bit < 8;
                mask <<= 1, ++bit)
    {
        // Pull DS low for 2us
        TEMP_DDR |= TEMP_DQ;
        delayUS(2);
        TEMP_DDR &= ~TEMP_DQ;

        // Wait for another 13 us until the recommended check time (15us)
        delayUS(13);

        // If the DQ line is set then it's a one
        if (TEMP_PIN & TEMP_DQ)
             val |= mask;

        // Wait another 47us until the minimum slot time
        delayUS(47);
    }

    // All 8 bits read. Return the value
    return val;
}

/* dsWriteByte() writes a byte to the DS1822
 *
 * Passed:
 *     val      Value to write
 *
 * Returns:
 *     nothing
 *
 * Notes:
 *     Assumes the port has the PORT bit set to zero and is
 *     an input (ie the pin is input and tristated)
 */
void
dsWriteByte(uint8_t val)
{
    uint8_t     mask;
    uint8_t     bit;

    for (       mask = 1, bit = 0;
                bit < 8;
                mask <<= 1, ++bit)
    {
        // Pull DS low for 2us
        TEMP_DDR |= TEMP_DQ;
        delayUS(2);

        // If the bit is one then let the line come up
        if (val & mask)
            TEMP_DDR &= ~TEMP_DQ;

        // Wait for the remaining time in the slot
        delayUS(60);
        
        // Let the line go high again for tREC
        TEMP_DDR &= ~TEMP_DQ;
        delayUS(5);
    }
}

/* tempInit() initializes the DS1822 sensor
 *
 * Passed:
 *         Nothing
 *
 * Returns:
 *         Nothing.
 */
void
tempInit(void)
{
    uint8_t     cfg;
    
    /* Initialize the device. This also detects whether the device is
     * preset. If it isn't then theres no need to do further initialization
     */
    if (dsInit())
    {
        /* Read the configuration register. The configuration register is
         * fifth byte from the scratchpad
         */
        dsWriteByte(0xcc);          // SKIP ROM command
        dsWriteByte(0xbe);          // READ SCRATCHPAD command

        dsReadByte();               // Skip the first four bytes
        dsReadByte();
        dsReadByte();
        dsReadByte();

        cfg = dsReadByte();         // This is the config byte

        if ((cfg & 0x60) != 0x20)   // Is (R1,R0) != 01 (ie. do we need to set?)
        {
            /* The device wasn't properly initialized. Initialize it. These
             * settings are saved in the DS1822 EEPROM, so this code should
             * only be run the first time the device has been started
             */
            dsInit();               // Initialize
            dsWriteByte(0xcc);      // SKIP ROM command
            dsWriteByte(0x4e);      // WRITE SCRATCHPAD command
            dsWriteByte(0x11);      // Dummy value
            dsWriteByte(0x99);      // Dummy value
            dsWriteByte(0x3f);      // R1 = 0, R0 = 1 (10 bit / 0.25deg per cnt)

            // Wait 10ms for the EEPROM write to complete
            delayUS(10000);
        }
    }
}

/* tempRead() reads the DS1822 temp sensor and returns the (sign extended)
 * value returned by the sensor.
 *
 * This value is 0 @ 0C, each count represents 0.25C
 *
 * Passed
 *      nothing
 *
 * Returns
 *      A value representing the temperature, as described above
 */
int16_t
tempRead(void)
{
    uint8_t     tempMSB;
    uint8_t     tempLSB;

    /* Turn off interrupts (the transfers in this function are 
     * timing sensitive)
     */
    cli();

    // Initialize the device. This also allows us to verify it is present
    if ( ! dsInit())
    {
        // No device present
        sei();
        return 0;
    }

    // Issue the temprature conversion command
    dsWriteByte(0xcc);          // SKIP ROM command
    dsWriteByte(0x44);          // CONVERT T command

    // Wait for a '1' to be returned on read
    while (dsReadByte() == 0)
        ;

    /* Reinitialize the device so we wan read the temperature from the
     * scratchpad and then read the first two bytes that contain
     * the converted temperature
     */
    dsInit();                   // Initialize
    dsWriteByte(0xcc);          // SKIP ROM command
    dsWriteByte(0xbe);          // READ SCRATCHPAD command

    tempLSB = dsReadByte();     // Read first byte (temp LSB)
    tempMSB = dsReadByte();     // Read second byte (temp MSB)

    /* Return the time. The format from the device has
     * four fractional bits, so we need to throw three away
     */
    sei();
    return (int16_t)(((uint16_t)tempMSB << 8) | (uint16_t)tempLSB) >> 2;
}
