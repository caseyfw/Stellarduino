/* 
 * Copyright (C) 2005 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: motion.c,v 1.4 2005/06/01 00:15:12 dbh Exp $
 */

#include <inttypes.h>
#include <stdlib.h>

#include "motion.h"
#include "stepper.h"
#include "sr.h"
#include "serial.h"

// Timer
static uint8_t          tmr;            // Inter microstep timer

// Pending requests
static int8_t           slewReq;        // Slew requested in direction
static uint8_t          gotoReq;        // GOTO request in progress

static uint8_t          stopReq;        // Stop requested

// Additional request parameters
static uint8_t          gotoLimit;      // Limit reported position to travel
static int32_t          curMove;        // First goto motion
static int32_t          nextMove;       // Second goto motion

// Current position
static uint8_t          subStep;        // microstep within step

/* motionInit() initializes the motion code
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
motionInit(void)
{
    // Cancel any pending commands
    motionStop();

    // Initialize currentStep and subStep
    subStep = gData.position % gData.ustepPerStep;
}

/* motionPoll() is called every tick (millisecond). It does whatever 
 * motion needs to be done. 
 *
 * This is where the real work is done - the other functions just not what
 * needs to be done
 *
 * Passed
 *      nothing
 *
 * Returns
 *     Bitmap of
 *
 *     M_IN             Moved one step in
 *     M_OUT            Moved one step out
 *     M_DONE           Motion done
 */
uint8_t
motionPoll(void)
{
    int8_t      move = 0;       // Move direction
    uint8_t     done = 0;       // Motion done
    uint8_t     result = 0;     // Result to return
    uint8_t     limit = 0;      // Limit position

    // Do the polling for the stepper motor
    stepperPoll();

    /* If the timer is zero then we can do the next action. 
     */
    if (tmr == 0 || gData.msPerUStep < 2)
    {
        if (stopReq && subStep == 0)
        {
            /* If we've been asked for a stop then do it if
             * we've reached the start of the step
             */
            done = 1;           // Stopped this tick

            slewReq = 0;        // Cancel all pending requests
            gotoReq = 0;
            stopReq = 0;
        }
        else if (gotoReq)
        {
            /* A GOTO has been requested, or is in progress. Do what needs
             * to be done
             */
            if (curMove == 0)
            {
                curMove = nextMove;
                nextMove = 0;
            }

            if (curMove != 0)
            {
                /* Ok, there is movement to do - do it
                 */
                move = (curMove > 0) ? 1 : -1;
                curMove -= move;        // Update move count
                ++tmr;                  // Kick of a timer cycle
                limit = gotoLimit;      // Limit step if required
            }
            else
            {
                // Move is complete - remove the request
                done = 1;               // Move done
                gotoReq = 0;            // Cancel request
            }
        }
        else if (slewReq)
        {
            /* Slew requested. Move in the specified direction.
             */
            move = slewReq > 0 ? 1 : -1;
            limit = 1;          // Limit reported position

            ++tmr;      // Kick off a timer cycle
        }

        /* Do the appropriate actions for each movement direction. The
         * subStep counter is always updated. If the travel is limited
         * we only update the microstep and step counters if we're
         * within the allowed travel range.
         *
         * Note the position updates and in/out indications occur
         * on step boundaries
         */
        if (move > 0)
        {
            /* Move in the positive direction, updating counters
             */
            stepperMove(1);

            if (++subStep >= gData.ustepPerStep)
            {
                // Wrap it around
                subStep = 0;
                result |= M_OUT;

                // Update the step count and microstep counter if allowed
                if (    (! limit)
                        || (    (gData.position + gData.ustepPerStep)
                                < gData.travel))
                {
                    gData.position += gData.ustepPerStep;
                }
            }
        }
        else if (move < 0)
        {
            /* Move in the negative direction, updating counters
             */
            stepperMove(-1);

            if (subStep-- == 0)
            {
                // Wrap it around
                subStep = gData.ustepPerStep - 1;
                result |= M_IN;

                // Update the step count and microstep counter if allowed
                if (    (! limit)
                        || ((gData.position - gData.ustepPerStep) >= 0))
                {
                    gData.position -= gData.ustepPerStep;
                }
            }
        }

        // Merge in the done indication
        if (done)
            result |= M_DONE;
    }
    else
    {
        // Update the timer, but no need to do anything else
        ++tmr;
        if (tmr >= gData.msPerUStep) 
            tmr = 0;
    }

    return result;
}

/* motionSlew() starts initiates slewing the in the specified direction
 * 
 * Passed
 *      dir     Slew direction (-1 = in, +1 = out)
 *
 * Returns
 *      nothing
 */
void
motionSlew(int8_t dir)
{
    slewReq = dir;
}

/* motionGoto() initiates a goto to a specified target position.
 *
 * Passed:
 *      first   The relative motion
 *      second  Next relative motion (can be zero)
 *      limit   Limit reported position to travel range
 *
 * Returns:
 *      nothing
 */
void
motionGoto(int32_t first, int32_t second, uint8_t limit)
{
    gotoReq = 1;
    curMove = first;
    nextMove = second;
    gotoLimit = limit;    
}

/* motionStop() stops any current motion
 *
 * Passed
 *      nothing
 *
 * Returns
 *      nothing
 */
void
motionStop(void)
{
    stopReq = 1;
}

/* motionCurrent() allows polling to determine whether the axis is still in
 * motion
 *
 * Passed
 *      nothing
 *
 * Returns
 *      0 if the axis is not in motion
 *      1 if the axis is in motion
 */
uint8_t
motionCurrent(void)
{
    return slewReq || gotoReq || stopReq;
}
