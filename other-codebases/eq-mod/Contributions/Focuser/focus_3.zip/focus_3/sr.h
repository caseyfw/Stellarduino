/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: sr.h,v 1.3 2005/09/25 08:54:23 dbh Exp $
 */

#ifndef __SR_H__
#define __SR_H__

#include <inttypes.h>

/* Define a structure to hold the persistent data
 */
typedef struct
{
    uint8_t     uninit;         // 0x0 for initialized, 0xff for blank eeprom

    /* Configuration data */
    uint8_t     ustepPerStep;   // # microsteps (fullsteps) per step
    uint8_t     msPerUStep;     // time b/w microsteps when running

    uint8_t     backlash;       // Number of full steps for backlash
    int8_t      endDir;         // End of move direction (-1 = in, 1 = out)

    uint8_t     duty;           // Duty cycle for stepper when not running

    /* Stepper state */
    int32_t     position;       // Position in microsteps
    uint8_t     phase;          // Current stepper phase

    uint32_t    travel;         // Maximum position in microsteps
} persist_t;

/* Define the global instance used by the code
 */
extern persist_t        gData;

/* Functions to save/restore data
 */
void srRead(void);
void srWrite(void);

#endif /* __SR_H__ */
