/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: consts.h,v 1.4 2005/09/25 08:54:23 dbh Exp $
 */

#ifndef _CONSTS_H_
#define _CONSTS_H_

#include <inttypes.h>

/* Define the default clock rate used by the software
 * replacement firmware
 */
#define DEF_CLK_RATE	(8L * 1000L * 1000L)	// 8 MHz

#ifndef CLK_RATE
#define CLK_RATE        DEF_CLK_RATE
#endif /* CLK_RATE */

/* Define the serial port baud rate */
#define GUIDE_BAUD      9600

/* Define the main timer rate. This is 1 ms per loop
 */
#define TMR_FREQ        1000U           /* Timer frequency in Hz */

/* Define the tick until after a stop that we power down the coils */
#define POWERDOWN_TICKS (30U * TMR_FREQ)       // 30 secs

/* Define the key debounce constants */
#define T_DEBOUNCE      10      // 10 ms debounce
#define T_REPT          500     // 500 ms to repeat time

/* Define how often to write changed data back to EEPROM */
#define SR_WRITEBACK    (15UL * TMR_FREQ)        // 15 seconds

#endif /* _CONSTS_H_ */
