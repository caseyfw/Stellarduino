/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: motion.h,v 1.3 2005/05/28 20:24:45 dbh Exp $
 */

#ifndef _MOTION_H_
#define _MOTION_H_

#include <inttypes.h>

/* Prototypes */
void motionInit(void);

uint8_t motionPoll(void);
/* Poll result bitmap */
#define M_DONE  0x1
#define M_IN    0x2
#define M_OUT   0x4

void motionSlew(int8_t dir);
void motionGoto(int32_t first, int32_t second, uint8_t limit);
void motionStop(void);
uint8_t motionCurrent(void);

#endif /* _MOTION_H_ */
