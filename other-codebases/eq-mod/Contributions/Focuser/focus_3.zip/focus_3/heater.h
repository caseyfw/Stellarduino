/* 
 * Copyright (C) 2004 Darren Hutchinson (dbh@gbdt.com.au)
 * 
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or (at your
 * option) any later version.
 *
 * This program is distributed in the hope that it will be useful, but
 * WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
 * or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public
 * License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this software; see the file COPYING.  If not, write to
 * the Free Software Foundation, Inc., 59 Temple Place - Suite 330, Boston,
 * MA 02111-1307, USA. 
 *
 * $Id: heater.h,v 1.1 2006/02/26 06:34:40 dbh Exp $
 */

#ifndef _HEATER_H_
#define _HEATER_H_

/* Bits used for the push buttons */
#define HEAT_PORT       PORTD
#define HEAT_DDR        DDRD

#define HEAT_VAL        _BV(PD2)

#define HEATER_RANGE    16

/* Functions in heater.c */
void heaterInit(void);
void heaterPoll(void);
void heaterSet(uint8_t level);
uint8_t heaterGet(void);

#endif /* _HEATER_H_ */
